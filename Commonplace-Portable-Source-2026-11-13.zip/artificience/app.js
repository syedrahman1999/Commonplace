/**
 * Artificience 4.0 — The Academic Evaluator
 * - Revisions appear inside the paper as tracked changes, each with ✓ Keep / ✕ Reject,
 *   a reason, a category and a strength, plus a list of changes the evaluator advises against.
 * - Appraisals return real rubric scores (no preset numbers) with concerns linked to passages.
 * - Documents: evaluation report, revision memo, clean copy, abstract, outline, reverse outline,
 *   cover letter, works cited, or any custom document.
 * - Export anything as PDF, Word (.docx), Markdown, plain text or HTML. Imports (PDF, Word,
 *   Markdown, text, HTML) are parsed properly and can be downloaded again in any of those formats.
 */
'use strict';

// ───────────────────────── Storage (IndexedDB + localStorage) ─────────────────────────
const DB_NAME = 'ArtificienceEvaluatorDB';
const DB_VERSION = 3; // v2 adds 'versions'; v3 adds 'meta' (settings and profile, kept durably)
let db = null;

const STORES = ['manuscripts', 'stacks', 'artifacts', 'versions', 'meta'];
// Writes made while storage isn't open yet (for example, an older Artificience window is holding it)
// are kept here and saved the moment storage opens, so nothing is lost.
const pending = Object.fromEntries(STORES.map(n => [n, new Map()]));
const deleted = Object.fromEntries(STORES.map(n => [n, new Set()]));
function openDb(version) {
  return new Promise((resolve) => {
    let req;
    try { req = version ? indexedDB.open(DB_NAME, version) : indexedDB.open(DB_NAME); } catch { return resolve(null); }
    req.onupgradeneeded = (e) => { const d = e.target.result; for (const n of STORES) if (!d.objectStoreNames.contains(n)) d.createObjectStore(n, { keyPath: 'id' }); };
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = () => resolve(null);
    req.onblocked = () => setStorageState('blocked');
  });
}
async function initDB() {
  // Open whatever version exists, which never waits on other windows. Upgrade only when a store is missing.
  let d = await openDb();
  if (d && !STORES.every(n => d.objectStoreNames.contains(n))) { const v = d.version + 1; d.close(); d = await openDb(v); }
  if (!d) { setStorageState('failed'); return null; }
  db = d;
  db.onversionchange = () => { db.close(); db = null; setTimeout(initDB, 400); }; // let a newer window upgrade, then reconnect
  setStorageState('ok');
  await flushPending();
  return db;
}
let storageState = 'opening';
function setStorageState(st) {
  storageState = st;
  const w = document.getElementById('storage-warning');
  if (st === 'ok') { hide(w); } else if (st === 'blocked' || st === 'failed') show(w);
  const note = document.getElementById('stacks-storage-note');
  if (note) note.classList.toggle('hidden', st === 'ok');
}
async function flushPending() {
  for (const n of STORES) {
    for (const id of deleted[n]) await dbDelete(n, id);
    deleted[n].clear();
    const items = [...pending[n].values()]; pending[n].clear();
    for (const item of items) await dbSave(n, item);
  }
  if (typeof renderStacks === 'function') renderStacks();
}
let warnedWrite = false;
function dbSave(store, item) {
  return new Promise((resolve) => {
    if (!db) { pending[store].set(item.id, item); deleted[store].delete(item.id); return resolve(false); }
    let tx;
    try { tx = db.transaction(store, 'readwrite'); tx.objectStore(store).put(item); }
    catch (err) { pending[store].set(item.id, item); return resolve(false); }
    tx.oncomplete = () => resolve(true);
    tx.onerror = tx.onabort = () => {
      pending[store].set(item.id, item);
      if (!warnedWrite) { warnedWrite = true; showToast(`Couldn’t save to this computer’s storage (${tx.error?.name || 'error'}). Your work is kept while this window is open.`, 6000); }
      resolve(false);
    };
  });
}
function dbGetAll(store) {
  return new Promise((resolve) => {
    const merge = (rows) => { const map = new Map(rows.filter(r => !deleted[store].has(r.id)).map(r => [r.id, r])); for (const [id, v] of pending[store]) map.set(id, v); return [...map.values()]; };
    if (!db) return resolve(merge([]));
    try { const req = db.transaction(store, 'readonly').objectStore(store).getAll(); req.onsuccess = () => resolve(merge(req.result || [])); req.onerror = () => resolve(merge([])); }
    catch { resolve(merge([])); }
  });
}
function dbGet(store, id) {
  return new Promise((resolve) => {
    if (pending[store].has(id)) return resolve(pending[store].get(id));
    if (deleted[store].has(id) || !db) return resolve(null);
    try { const req = db.transaction(store, 'readonly').objectStore(store).get(id); req.onsuccess = () => resolve(req.result || null); req.onerror = () => resolve(null); }
    catch { resolve(null); }
  });
}
function dbDelete(store, id) {
  return new Promise((resolve) => {
    pending[store].delete(id);
    if (!db) { deleted[store].add(id); return resolve(); }
    try { const tx = db.transaction(store, 'readwrite'); tx.objectStore(store).delete(id); tx.oncomplete = () => resolve(); tx.onerror = () => resolve(); }
    catch { deleted[store].add(id); resolve(); }
  });
}
const lsGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

// ───────────────────────── State ─────────────────────────
const state = {
  currentDocId: lsGet('artificience_last_doc') || 'doc_active',
  title: '',
  content: '',
  activeFramework: 'aacu_written',
  attachedImages: [],
  appraisals: [],       // newest first: { at, framework, result }
  review: null,         // { edits:[], notRecommended:[], scope:{start,end}, focus, createdAt, sectionsDone, sectionsTotal }
  lastReview: null,     // the last applied review (for the revision memo / Word appendix)
  busy: false,
  abort: null,
  mode: 'ask',
  selection: null,      // { start, end, text } captured from the editor
  reviewCursor: -1,
  undoStack: [],
  openDoc: null,
  profile: { tier: '', tierLabel: '', major: '', gpa: '', name: '', institution: '', instructor: '', course: '' },
  settings: {
    apiUrl: 'https://api.openai.com/v1',
    apiKey: '',
    model: 'gpt-4o-mini',
    customStandards: '',
    intensity: 'standard',
    exportStyle: 'academic'
  }
};

function removeLegacyPublicProfile() {
  const wasBundledProfile = /^Upper Senior\b.*GPA$/i.test(state.profile.tierLabel || '') && /^3\.\d{3} GPA · Senior Honors Track$/i.test(state.profile.gpa || '');
  if (wasBundledProfile) Object.assign(state.profile, { tier: '', tierLabel: '', major: '', gpa: '', name: '', institution: '', instructor: '', course: '' });
}
function profileLabel() { return String(state.profile.tierLabel || state.profile.major || state.profile.gpa || 'No credentials added').split('(')[0].trim(); }
function loadStoredState() {
  try { const p = lsGet('artificience_prof_v3'); if (p) Object.assign(state.profile, JSON.parse(p)); } catch {}
  try { const c = lsGet('artificience_cfg_v3'); if (c) Object.assign(state.settings, JSON.parse(c)); } catch {}
  removeLegacyPublicProfile();
}
// Settings and profile are written to both quick storage and the durable database, stamped with
// the time, so a fresh window never starts from a stale or missing copy.
function persistSettings() { state.settings._at = Date.now(); lsSet('artificience_cfg_v3', JSON.stringify(state.settings)); return dbSave('meta', { id: 'settings', value: { ...state.settings } }); }
function persistProfile() { state.profile._at = Date.now(); lsSet('artificience_prof_v3', JSON.stringify(state.profile)); return dbSave('meta', { id: 'profile', value: { ...state.profile } }); }
function saveProfileState() { persistProfile(); showToast('Scholar profile updated.'); }
function saveSettingsState() { persistSettings(); showToast('Settings saved.'); }
async function loadDurableSettings() {
  const [s, p] = await Promise.all([dbGet('meta', 'settings'), dbGet('meta', 'profile')]);
  let changed = false;
  if (s?.value && (s.value._at || 0) > (state.settings._at || 0)) { Object.assign(state.settings, s.value); changed = true; }
  if (p?.value && (p.value._at || 0) > (state.profile._at || 0)) { Object.assign(state.profile, p.value); changed = true; }
  removeLegacyPublicProfile();
  // first run of 4.2: copy what quick storage had into the database
  if (!s && state.settings._at === undefined && (state.settings.apiKey || state.settings.customStandards)) persistSettings();
  if (!s && state.settings._at) persistSettings();
  if (!p && state.profile._at) persistProfile();
  if (changed) fillSettingsFields();
}
function fillSettingsFields() {
  dom.profileLevelLabel.textContent = profileLabel();
  $('prof-tier-select').value = state.profile.tier; $('prof-major-input').value = state.profile.major; $('prof-gpa-input').value = state.profile.gpa;
  $('cfg-api-url').value = state.settings.apiUrl; $('cfg-api-key').value = state.settings.apiKey; $('cfg-model').value = state.settings.model;
  $('cfg-custom-standards').value = state.settings.customStandards || ''; $('cfg-intensity').value = state.settings.intensity || 'standard'; $('cfg-export-style').value = state.settings.exportStyle || 'academic';
  updateEngineStatus(); window.Features?.refreshSettings?.();
}

// ───────────────────────── DOM ─────────────────────────
const $ = (id) => document.getElementById(id);
const dom = {
  docTitleInput: $('doc-title-input'), savePill: $('save-pill'),
  profileLevelLabel: $('profile-level-label'), frameworkSelect: $('framework-select'),
  evaluatorPanel: $('evaluator-panel'),
  editor: $('manuscript-editor'), stage: $('diff-review-stage'), dropzone: $('editor-dropzone'),
  images: $('image-attachments-row'), fileImport: $('omnibox-file-import'),
  btnAppraise: $('btn-appraise'), btnRevise: $('btn-revise-inline'), btnReviseSel: null,
  workStatus: $('work-status'), workStatusText: $('work-status-text'),
  banner: $('diff-banner'), reviewProgress: $('review-progress'), reviewFill: $('review-progress-fill'),
  feed: $('resonator-stream'), ledger: $('revisions-ledger'),
  directive: $('scribe-directive-input'), modeHint: $('mode-hint'),
  revisionsCount: $('revisions-count'), artifactsCount: $('artifacts-count'), artifactsList: $('artifacts-list'),
  exportMenu: $('export-popover-menu'),
  stacksList: $('stacks-items-list'), stacksCount: $('stacks-count'), stacksInput: $('stacks-input'),
  toastDeck: $('toast-deck')
};

function showToast(msg, ms = 2600) {
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  dom.toastDeck.appendChild(t);
  while (dom.toastDeck.children.length > 3) dom.toastDeck.firstElementChild.remove();
  setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateY(8px)'; t.style.transition = 'all .2s ease'; setTimeout(() => t.remove(), 220); }, ms);
}
function escapeHTML(str) {
  return String(str ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}
const show = (el) => el && el.classList.remove('hidden');
const hide = (el) => el && el.classList.add('hidden');
const words = (t) => (t.trim() ? t.trim().split(/\s+/).length : 0);
const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
const LENS_NAMES = () => Object.fromEntries([...dom.frameworkSelect.options].map(o => [o.value, o.text]));

// AI features need an engine; if none is set up, open Settings instead of failing.
function requireEngine() {
  if (state.settings.apiKey || !/openai\.com/.test(state.settings.apiUrl)) return true;
  show($('modal-settings')); $('cfg-api-key').focus();
  showToast('Add your API key (or an Ollama address) to use the evaluator. Writing, importing and exporting work without one.', 5000);
  return false;
}
function setBusy(text) {
  state.busy = !!text;
  dom.btnAppraise.disabled = !!text; dom.btnRevise.disabled = !!text;
  updateSelectionButton();
  if (text) { dom.workStatusText.textContent = text; show(dom.workStatus); } else hide(dom.workStatus);
}

// ───────────────────────── Papers: editing, saving, library ─────────────────────────
let saveTimer = null;
function handleEditorInput() {
  state.html = RichEditor.getHtml();
  state.content = RichEditor.toMarkdown();
  dom.savePill.textContent = 'Saving…';
  RichEditor.setSaved('Saving…');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persistDocument, 700);
}
function currentRecord() {
  return {
    id: state.currentDocId,
    title: state.title.trim() || 'Untitled Paper',
    content: state.content,
    html: state.html,
    docStyle: RichEditor.getDocStyle(),
    framework: state.activeFramework,
    attachedImages: state.attachedImages,
    appraisals: state.appraisals.slice(0, 10),
    review: state.review,
    lastReview: state.lastReview,
    peer: state.peer || null,
    updatedAt: new Date().toISOString()
  };
}
async function persistDocument() {
  await dbSave('manuscripts', currentRecord());
  window.Features?.autoVersion?.();
  lsSet('artificience_last_doc', state.currentDocId);
  dom.savePill.textContent = 'Saved';
  RichEditor.setSaved('All changes saved on this computer');
}
function applyRecord(rec) {
  state.currentDocId = rec.id;
  state.title = rec.title === 'Untitled Paper' ? '' : (rec.title || '');
  state.content = rec.content || '';
  state.activeFramework = rec.framework || 'senior_honors';
  state.attachedImages = rec.attachedImages || [];
  state.appraisals = rec.appraisals || [];
  state.review = rec.review || null;
  state.lastReview = rec.lastReview || null;
  state.peer = rec.peer || null;
  state.undoStack = [];
  dom.docTitleInput.value = state.title;
  RichEditor.setHtml(rec.html || RichEditor.fromMarkdown(state.content), rec.docStyle);
  dom.frameworkSelect.value = state.activeFramework;
  renderImageThumbnails();
  handleEditorInput();
  renderAppraisalFeed();
  if (state.review && state.review.edits.length) openReview(); else closeReviewView();
  renderLedger();
  renderArtifactsStack();
  window.Features?.onPaperOpened?.();
}
async function loadDocument() {
  const docs = await dbGetAll('manuscripts');
  const active = docs.find(d => d.id === state.currentDocId) || docs.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''))[0];
  if (active) applyRecord(active); else { renderAppraisalFeed(); renderLedger(); renderArtifactsStack(); }
}
function setPaperMarkdown(md) { RichEditor.setHtml(RichEditor.fromMarkdown(md)); handleEditorInput(); }
function appendPaperMarkdown(md) { RichEditor.setHtml(RichEditor.getHtml() + RichEditor.fromMarkdown(md)); handleEditorInput(); }
async function openPaper(id) {
  if (id === state.currentDocId) return;
  await persistDocument();
  const rec = await dbGet('manuscripts', id);
  if (rec) { applyRecord(rec); lsSet('artificience_last_doc', id); showToast(`Opened “${rec.title}”.`); }
}
async function newPaper(title = '', content = '') {
  await persistDocument();
  applyRecord({ id: 'doc_' + Date.now(), title, content, framework: state.activeFramework, attachedImages: [], docStyle: RichEditor.getDocStyle() });
  await persistDocument();
}
async function openPapers() {
  const docs = (await dbGetAll('manuscripts')).sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  showInfo('Your papers', docs.length ? `<div class="papers-list">${docs.map(d => `
    <div class="paper-row ${d.id === state.currentDocId ? 'current' : ''}">
      <button class="paper-open" data-open="${escapeHTML(d.id)}"><strong>${escapeHTML(d.title || 'Untitled Paper')}</strong><small>${words(d.content || '')} words · ${d.updatedAt ? fmtDate(d.updatedAt) : ''}${d.review?.edits?.length ? ' · revisions open' : ''}</small></button>
      ${d.id === state.currentDocId ? '<span class="paper-current">Open now</span>' : `<button class="btn-download danger" data-del="${escapeHTML(d.id)}" title="Delete this paper">Delete</button>`}
    </div>`).join('')}</div><div class="modal-actions-row"><button class="btn-modal-primary" id="papers-new">+ New paper</button><button class="btn-modal-secondary" id="papers-import">Import a file…</button></div>` : '<div class="empty-state">No papers yet.</div>', (body) => {
    body.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => { closeInfo(); openPaper(b.dataset.open); }));
    body.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => { const rec = await dbGet('manuscripts', b.dataset.del); if (rec && confirm(`Delete “${rec.title}”? This cannot be undone.`)) { await dbDelete('manuscripts', rec.id); openPapers(); showToast('Paper deleted.'); } }));
    $('papers-new')?.addEventListener('click', () => { closeInfo(); App.newPaper(); });
    $('papers-import')?.addEventListener('click', () => { closeInfo(); dom.fileImport.click(); });
  });
}
async function duplicatePaper() {
  if (state.review) { showToast('Apply or cancel the open revision review first.'); return; }
  const html = RichEditor.getHtml(), style = RichEditor.getDocStyle();
  await persistDocument();
  applyRecord({ id: 'doc_' + Date.now(), title: (state.title || 'Untitled Paper') + ' (copy)', content: state.content, html, docStyle: style, framework: state.activeFramework, attachedImages: state.attachedImages });
  await persistDocument(); showToast('Copy created.');
}
async function deleteCurrentPaper() {
  if (!confirm(`Delete “${state.title || 'Untitled Paper'}”? This cannot be undone.`)) return;
  const id = state.currentDocId; await dbDelete('manuscripts', id);
  const docs = (await dbGetAll('manuscripts')).sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  if (docs[0]) applyRecord(docs[0]); else applyRecord({ id: 'doc_' + Date.now(), title: '', content: '' });
  persistDocument(); showToast('Paper deleted.');
}
// General dialog for information and small forms
function showInfo(title, html, onReady) { $('info-title').textContent = title; const body = $('info-body'); body.innerHTML = html; show($('modal-info')); onReady && onReady(body); }
function closeInfo() { hide($('modal-info')); }
const HELP = {
  how: ['How Artificience works', `<ol class="intro-steps"><li><strong>Write or import</strong> your paper on the page. Use the menus and toolbar like Word or Google Docs: fonts, sizes, styles, alignment, spacing, lists, tables and images.</li><li><strong>Run Appraisal</strong> for a rubric grade with criterion scores, strengths and concerns. Click any quoted passage to jump to it.</li><li><strong>Suggest Scholarly Revisions</strong> marks every proposed change in your paper. Keep (✓) or reject (✕) each one, or adjust its wording in the Revisions tab. Apply my decisions writes only what you kept; your formatting is preserved.</li><li><strong>Revise selection</strong>: highlight a passage, then choose it in the toolbar to revise only that passage.</li><li><strong>Documents</strong>: create reports, memos, abstracts, outlines, cover letters, works cited or anything custom, and download them as PDF, Word, Markdown or text.</li><li><strong>Focus</strong> (next to the appraisal button) narrows feedback to argument, evidence, structure, style, clarity or grammar.</li><li><strong>Insights</strong> charts readability, sentence rhythm and progress across versions, without AI.</li><li><strong>Peers</strong>: send a review file to a classmate; import their review to see comments linked to passages.</li><li><strong>File → Version history</strong> lets you preview, compare and restore earlier versions.</li><li><strong>The Stacks</strong> holds your reference files; the evaluator reads them as context.</li></ol>`],
  keys: ['Keyboard shortcuts', `<table class="wc-table"><tr><td>Run appraisal</td><td>⌘↵</td></tr><tr><td>Suggest revisions (selection or paper)</td><td>⇧⌘↵</td></tr><tr><td>Bold / Italic / Underline</td><td>⌘B / ⌘I / ⌘U</td></tr><tr><td>Align left / center / right / justify</td><td>⇧⌘L / ⇧⌘E / ⇧⌘R / ⇧⌘J</td></tr><tr><td>Bigger / smaller text</td><td>⇧⌘. / ⇧⌘,</td></tr><tr><td>Insert link</td><td>⌘K</td></tr><tr><td>Find and replace</td><td>⌘F</td></tr><tr><td>Word count</td><td>⇧⌘C</td></tr><tr><td>Print or save as PDF</td><td>⌘P</td></tr><tr><td>Clear formatting</td><td>⌘\\</td></tr><tr><td>Save now</td><td>⌘S</td></tr><tr><td>Show or hide the evaluator panel</td><td>⌘E</td></tr><tr><td colspan="2"><strong>While reviewing revisions</strong></td></tr><tr><td>Keep / reject the current change</td><td>Y / N</td></tr><tr><td>Next / previous change</td><td>J / K</td></tr><tr><td>Undo the last decision</td><td>U</td></tr></table>`],
  about: ['About Artificience', `<p class="about-text"><strong>Artificience 4.3.0</strong> — an academic evaluator and revision instrument.</p><p class="about-text">Your papers, profile, documents, references and settings are stored separately in this browser. Every new visitor begins with an empty profile and supplies their own information. The AI is called only when you run an appraisal, ask for revisions, ask a question or create a document, using the engine in Settings.</p><p class="about-text field-hint">Bundled libraries: Mammoth.js (BSD-2), PDF.js (Apache-2.0), docx (MIT).</p>`]
};
function showHelp(kind) { const [t, h] = HELP[kind] || HELP.how; showInfo(t, h); }

// ───────────────────────── File ingestion ─────────────────────────
function readFileAsText(file) { return file.text ? file.text() : new Promise(r => { const f = new FileReader(); f.onload = e => r(e.target.result || ''); f.onerror = () => r(''); f.readAsText(file); }); }
function readFileDataUrl(file) { return new Promise(r => { const f = new FileReader(); f.onload = e => r(e.target.result || ''); f.onerror = () => r(''); f.readAsDataURL(file); }); }

// Turns HTML (from Word via Mammoth, or an .html file) into Markdown-style text that keeps headings, lists and quotes.
function htmlToText(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const out = [];
  const inline = (node) => {
    let s = '';
    node.childNodes.forEach(n => {
      if (n.nodeType === 3) s += n.textContent;
      else if (n.nodeType === 1) {
        const tag = n.tagName.toLowerCase(), inner = inline(n);
        if (tag === 'br') s += '\n';
        else if ((tag === 'strong' || tag === 'b') && inner.trim()) s += `**${inner}**`;
        else if ((tag === 'em' || tag === 'i') && inner.trim()) s += `*${inner}*`;
        else s += inner;
      }
    });
    return s;
  };
  const walk = (node) => {
    node.childNodes.forEach(n => {
      if (n.nodeType === 3) { if (n.textContent.trim()) out.push(n.textContent.trim()); return; }
      if (n.nodeType !== 1) return;
      const tag = n.tagName.toLowerCase();
      if (/^h[1-6]$/.test(tag)) out.push('#'.repeat(Math.min(3, Math.max(1, +tag[1]))) + ' ' + inline(n).trim());
      else if (tag === 'p') { const t = inline(n).trim(); if (t) out.push(t); }
      else if (tag === 'blockquote') out.push(inline(n).trim().split('\n').map(l => '> ' + l).join('\n'));
      else if (tag === 'ul' || tag === 'ol') { let i = 1; n.querySelectorAll(':scope > li').forEach(li => out.push((tag === 'ol' ? `${i++}.` : '-') + ' ' + inline(li).trim())); }
      else if (tag === 'table') n.querySelectorAll('tr').forEach(tr => out.push([...tr.children].map(td => inline(td).trim()).join(' | ')));
      else if (['script', 'style', 'head'].includes(tag)) return;
      else walk(n);
    });
  };
  walk(doc.body);
  return out.join('\n\n').replace(/\n{3,}/g, '\n\n').trim();
}
// Rebuilds lines and paragraphs from PDF text positions instead of one run-on string.
// A paragraph break is a line gap clearly wider than the document's normal line spacing,
// or a short line that ends a sentence.
async function pdfToText(arrayBuffer) {
  const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const pages = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const tc = await page.getTextContent();
    const lines = [];
    for (const item of tc.items) {
      if (!('str' in item) || !item.str) continue;
      const y = item.transform[5], x = item.transform[4], h = Math.abs(item.transform[3]) || 10;
      const last = lines[lines.length - 1];
      if (last && Math.abs(last.y - y) < h * 0.45) { last.text += (last.text.endsWith(' ') || item.str.startsWith(' ') ? '' : (x - last.right > h * 0.15 ? ' ' : '')) + item.str; last.right = x + (item.width || 0); }
      else lines.push({ y, x, h, text: item.str, right: x + (item.width || 0) });
    }
    pages.push(lines);
  }
  const gaps = [];
  pages.forEach(lines => lines.forEach((l, i) => { if (i) { const g = lines[i - 1].y - l.y; if (g > 0) gaps.push(g / l.h); } }));
  gaps.sort((a, b) => a - b);
  const normal = gaps.length ? gaps[Math.floor(gaps.length / 2)] : 1.2;
  const widest = Math.max(1, ...pages.flat().map(l => l.right - l.x));
  const paragraphs = [];
  let current = '';
  const flush = () => { if (current.trim()) paragraphs.push(current.trim()); current = ''; };
  pages.forEach(lines => lines.forEach((l, i) => {
    const t = l.text.replace(/\s+/g, ' ').trim();
    if (!t || /^\d{1,4}$/.test(t)) return; // blank lines and bare page numbers
    const prev = i ? lines[i - 1] : null;
    const gap = prev ? (prev.y - l.y) / l.h : 0;
    const prevShortEnd = prev && /[.!?:"\u201D)]$/.test(prev.text.trim()) && (prev.right - prev.x) < widest * 0.8;
    const sizeChange = prev && Math.abs(prev.h - l.h) > Math.max(prev.h, l.h) * 0.15; // e.g. a heading
    if (current && (gap > normal * 1.3 || gap < 0 || prevShortEnd || sizeChange)) flush();
    current = current ? (current.endsWith('-') ? current.slice(0, -1) + t : current + ' ' + t) : t;
  }));
  flush();
  return { text: paragraphs.join('\n\n'), pages: pdf.numPages };
}
// Extracts readable text from any supported file. Returns { text, note }.
async function extractText(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (ext === 'pdf') {
    if (!window.pdfjsLib) throw new Error('The PDF reader did not load.');
    const r = await pdfToText(await file.arrayBuffer());
    if (!r.text.trim()) throw new Error('This PDF has no selectable text (it may be a scan).');
    return { text: r.text, note: `${r.pages} pages` };
  }
  if (ext === 'docx') {
    if (!window.mammoth) throw new Error('The Word reader did not load.');
    const r = await window.mammoth.convertToHtml({ arrayBuffer: await file.arrayBuffer() });
    return { text: htmlToText(r.value), note: 'Word document' };
  }
  if (ext === 'doc') throw new Error('Older .doc files can’t be read. In Word, choose File → Save As → .docx, then import that.');
  if (ext === 'html' || ext === 'htm') return { text: htmlToText(await readFileAsText(file)), note: 'web page' };
  if (ext === 'rtf') {
    const raw = await readFileAsText(file);
    const text = raw.replace(/\\par[d]?/g, '\n\n').replace(/\{\\[^{}]*\}/g, '').replace(/\\[a-z]+-?\d* ?/gi, '').replace(/[{}]/g, '').replace(/\n{3,}/g, '\n\n').trim();
    return { text, note: 'rich text' };
  }
  return { text: (await readFileAsText(file)).replace(/\r\n?/g, '\n'), note: ext.toUpperCase() };
}
async function processUploadedFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (['png', 'jpg', 'jpeg', 'webp'].includes(ext)) {
    state.attachedImages.push({ name: file.name, dataUrl: await readFileDataUrl(file) });
    renderImageThumbnails(); persistDocument(); showToast(`Attached image: ${file.name}`); return;
  }
  if (ext === 'json') {
    try {
      const data = JSON.parse(await readFileAsText(file));
      if (data.app === 'Artificience' && Array.isArray(data.manuscripts)) { await restoreWorkspace(data); return; }
      if (/^artificience-peer-/.test(data.type || '') && window.Features) { await window.Features.importPeer(data); return; }
    } catch {}
  }
  showToast(`Reading ${file.name}…`);
  try {
    const { text, note } = await extractText(file);
    if (state.review) { showToast('Finish or cancel the open revision review before importing.'); return; }
    const title = file.name.replace(/\.[^/.]+$/, '');
    if (!state.content.trim()) {
      setPaperMarkdown(text); state.title = title; dom.docTitleInput.value = title;
    } else if (confirm(`Open “${title}” as a new paper?\n\nOK = new paper · Cancel = add it to the end of this paper`)) {
      await newPaper(title, text);
      showToast(`Imported ${file.name} (${note}) as a new paper.`); return;
    } else appendPaperMarkdown(`## ${title}\n\n` + text);
    handleEditorInput();
    showToast(`Imported ${file.name} (${note}).`);
  } catch (err) { showToast(`Couldn’t import ${file.name}: ${err.message}`, 5000); }
}
async function restoreWorkspace(data) {
  if (!confirm(`Restore ${data.manuscripts.length} papers, ${data.stacks?.length || 0} references and ${data.artifacts?.length || 0} documents from this backup? Items with the same ID are replaced.`)) return;
  for (const m of data.manuscripts) await dbSave('manuscripts', m);
  for (const s of data.stacks || []) await dbSave('stacks', s);
  for (const a of data.artifacts || []) await dbSave('artifacts', a);
  await renderStacks(); await renderArtifactsStack();
  showToast('Workspace restored. Open papers from the Papers menu.');
}
function renderImageThumbnails() {
  if (!state.attachedImages.length) { hide(dom.images); dom.images.innerHTML = ''; return; }
  show(dom.images);
  dom.images.innerHTML = state.attachedImages.map((img, i) => `<div class="image-thumb-card"><img src="${img.dataUrl}" alt="${escapeHTML(img.name)}" /><button class="image-thumb-remove" data-idx="${i}">✕</button></div>`).join('');
  dom.images.querySelectorAll('.image-thumb-remove').forEach(b => b.addEventListener('click', () => { state.attachedImages.splice(+b.dataset.idx, 1); renderImageThumbnails(); persistDocument(); }));
}

// ───────────────────────── Rubrics ─────────────────────────
const RUBRIC_LENSES = {
  senior_honors: `UPPER-SENIOR HONORS & CAPSTONE STANDARD — criteria: Conceptual Fertility & Ambition; Engagement with Disciplinary Literature; Argumentative Coherence & Counter-argument; Diction & Scholarly Tone.`,
  aacu_critical: `AAC&U VALUE RUBRIC: CRITICAL THINKING — criteria: Explanation of Issues; Evidence; Influence of Context & Assumptions; Student's Position (Thesis); Conclusions & Related Outcomes.`,
  aacu_written: `AAC&U VALUE RUBRIC: WRITTEN COMMUNICATION — criteria: Context & Purpose; Content Development; Genre & Disciplinary Conventions; Sources & Evidence; Control of Syntax & Mechanics.`,
  graduate_thesis: `GRADUATE / MASTER'S THESIS — criteria: Research Question & Significance; Literature Review; Methodological Precision; Structural Coherence; Scholarly Writing.`,
  doctoral_peer: `DOCTORAL / PEER-REVIEW STANDARD — criteria: Original Contribution; Engagement with Competing Paradigms; Methodological Rigor; Evidence & Argument; Publication Readiness.`,
  danielson: `DANIELSON FRAMEWORK FOR TEACHING — criteria: Domain 1 Planning & Preparation; Domain 2 Classroom Environment; Domain 3 Instruction; Domain 4 Professional Responsibilities.`,
  udl: `UNIVERSAL DESIGN FOR LEARNING — criteria: Multiple Means of Engagement; Multiple Means of Representation; Multiple Means of Action & Expression.`,
  crp: `CRITICAL RACE & CULTURALLY SUSTAINING PEDAGOGY (Ladson-Billings; Tate; Paris & Alim) — criteria: Academic Success; Cultural Competence & Sustenance; Critical Consciousness; Counter-narrative.`,
  raciolinguistics: `RACIOLINGUISTIC PERSPECTIVES (Flores & Rosa) — criteria: Asset Framing of Language Practices; Translanguaging & Code-meshing; Critique of Racialized Listening; Implications for Practice.`,
  toulmin: `TOULMIN ARGUMENT MODEL — criteria: Claim; Grounds; Warrant; Backing; Qualifier; Rebuttal.`,
  conceptual_vitality: `CONCEPTUAL VITALITY & ORIGINAL INSIGHT — criteria: Originality of Conception; Structural Necessity; Aesthetic & Rhetorical Control; Intellectual Risk.`
};

function contextBlock(stacks) {
  const canon = state.settings.customStandards ? `\n[CUSTOM STANDARDS / THEORISTS]\n${state.settings.customStandards}` : '';
  let refs = '';
  if (stacks.length) {
    let budget = 6000;
    refs = '\n[REFERENCE LIBRARY — the scholar’s own sources; use only to judge accuracy and fit, never quote as if from the paper]\n' +
      stacks.map(s => { const t = (s.text || '').slice(0, Math.max(0, Math.min(1500, budget))); budget -= t.length; return t ? `— ${s.name}: ${t}` : ''; }).filter(Boolean).join('\n');
  }
  const focus = (state.settings.focus || []).length ? `\n[FEEDBACK FOCUS]\nThe scholar asked you to concentrate on: ${state.settings.focus.join(', ')}. Give these areas most of your attention; mention other issues only if they are serious.` : '';
  const profile = [['Level', state.profile.tierLabel], ['Field', state.profile.major], ['Standing', state.profile.gpa]].filter(([, value]) => value).map(([label, value]) => `${label}: ${value}`).join('\n');
  return (profile ? `[USER-PROVIDED ACADEMIC CONTEXT]\n${profile}\nUse this context only to calibrate expectations. Never infer credentials that were not entered.\n` : `[ACADEMIC CONTEXT]\nNo credentials, honors, GPA, institution, or personal profile were supplied. Judge only the submitted writing against the selected rubric.\n`) +
    `Be respectful and specific. Never inflate praise or scores because of credentials or standing; credit only what the text earns.\n` +
    `\n[RUBRIC]\n${RUBRIC_LENSES[state.activeFramework] || RUBRIC_LENSES.senior_honors}${canon}${focus}${refs}`;
}

// ───────────────────────── AI connection ─────────────────────────
function endpoint() { return (state.settings.apiUrl || 'https://api.openai.com/v1').replace(/\/+$/, '') + '/chat/completions'; }
async function readError(res) {
  let detail = '';
  try { const j = await res.json(); detail = j.error?.message || j.message || ''; } catch {}
  if (res.status === 401) return 'The API key was not accepted. Check it in Settings.';
  if (res.status === 404) return `The model “${state.settings.model}” or the endpoint was not found. Check Settings.${detail ? ' (' + detail + ')' : ''}`;
  if (res.status === 429) return /quota|billing/i.test(detail) ? 'Your API account has no remaining credit or hit its billing limit.' : 'Too many requests right now. Wait a moment and try again.';
  return `The AI service returned an error (${res.status})${detail ? ': ' + detail : ''}`;
}
async function callChat({ system, user, images = [], maxTokens = 1500, json = false, stream = false, onDelta = null, temperature = 0.3 }) {
  if (!state.settings.apiKey && /openai\.com/.test(state.settings.apiUrl)) throw new Error('Add your API key in Settings (the gear icon) first.');
  const headers = { 'Content-Type': 'application/json' };
  if (state.settings.apiKey) headers.Authorization = `Bearer ${state.settings.apiKey.trim()}`;
  const content = images.length ? [{ type: 'text', text: user }, ...images.map(i => ({ type: 'image_url', image_url: { url: i.dataUrl } }))] : user;
  const body = { model: state.settings.model || 'gpt-4o-mini', messages: [{ role: 'system', content: system }, { role: 'user', content }], max_tokens: maxTokens, temperature, stream };
  if (json) body.response_format = { type: 'json_object' };
  state.abort = new AbortController();
  let res = await fetch(endpoint(), { method: 'POST', headers, body: JSON.stringify(body), signal: state.abort.signal });
  for (let attempt = 0; attempt < 2 && !res.ok && res.status === 400; attempt++) {
    const detail = await res.clone().text().catch(() => '');
    let changed = false;
    // Newer OpenAI models (gpt-5, o-series) want max_completion_tokens and the default temperature.
    if (/max_tokens/.test(detail) && body.max_tokens) { body.max_completion_tokens = body.max_tokens; delete body.max_tokens; changed = true; }
    if (/temperature/.test(detail) && 'temperature' in body) { delete body.temperature; changed = true; }
    // Some local models reject response_format.
    if (/response_format|json/i.test(detail) && body.response_format) { delete body.response_format; changed = true; }
    if (!changed) break;
    res = await fetch(endpoint(), { method: 'POST', headers, body: JSON.stringify(body), signal: state.abort.signal });
  }
  if (!res.ok) throw new Error(await readError(res));
  if (!stream) {
    const data = await res.json();
    const choice = data.choices?.[0];
    return { text: choice?.message?.content || '', truncated: choice?.finish_reason === 'length' };
  }
  const reader = res.body.getReader(), decoder = new TextDecoder();
  let buffer = '', text = '', truncated = false;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n'); buffer = lines.pop();
    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith('data:') || t === 'data: [DONE]') continue;
      try {
        const j = JSON.parse(t.slice(5).trim());
        const d = j.choices?.[0]?.delta?.content;
        if (j.choices?.[0]?.finish_reason === 'length') truncated = true;
        if (d) { text += d; onDelta && onDelta(text); }
      } catch {}
    }
  }
  return { text, truncated };
}
function parseJSON(text) {
  const clean = String(text || '').replace(/^\s*```(?:json)?/i, '').replace(/```\s*$/, '').trim();
  try { return JSON.parse(clean); } catch {}
  const a = clean.indexOf('{'), b = clean.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(clean.slice(a, b + 1)); } catch {} }
  return null;
}

// ───────────────────────── Locating quoted passages in the paper ─────────────────────────
// Normalizes quotes, dashes and whitespace while remembering original positions.
function normMap(text) {
  let norm = '', map = [], prevSpace = false;
  for (let i = 0; i < text.length; i++) {
    let c = text[i];
    if (/[‘’‚′]/.test(c)) c = "'";
    else if (/[“”„″]/.test(c)) c = '"';
    else if (/[–—−]/.test(c)) c = '-';
    else if (c === '…') c = '.';
    if (/\s/.test(c)) { if (prevSpace) continue; c = ' '; prevSpace = true; } else prevSpace = false;
    norm += c.toLowerCase(); map.push(i);
  }
  return { norm, map };
}
function locate(text, quote, from = 0, to = text.length) {
  const q = String(quote || '').trim();
  if (q.length < 3) return null;
  const slice = text.slice(from, to);
  let i = slice.indexOf(q);
  if (i >= 0) return [from + i, from + i + q.length];
  const t = normMap(slice), n = normMap(q).norm.trim();
  i = t.norm.indexOf(n);
  if (i < 0 && n.length > 60) { // try the opening and closing words of a long quote
    const head = n.slice(0, 40), tail = n.slice(-40);
    const h = t.norm.indexOf(head), e = h >= 0 ? t.norm.indexOf(tail, h) : -1;
    if (h >= 0 && e >= 0 && e - h < n.length * 1.5) return [from + t.map[h], from + t.map[e + tail.length - 1] + 1];
  }
  if (i < 0) return null;
  return [from + t.map[i], from + t.map[i + n.length - 1] + 1];
}

// ───────────────────────── Appraisal (real scores) ─────────────────────────
const APPRAISAL_SCHEMA = `Return one JSON object:
{"score": integer 0-100,
 "standing": "short label, e.g. 'Strong draft — revise before submission'",
 "criteria": [{"name": "criterion from the rubric", "score": integer 0-100, "comment": "one or two specific sentences"}],
 "summary": "2-4 sentences: the paper's central claim and how well it is carried",
 "strengths": [{"point": "specific strength", "quote": "short exact quote from the paper"}],
 "concerns": [{"issue": "specific problem", "quote": "short exact quote (under 25 words) from where it occurs", "suggestion": "what to do", "severity": "major|minor"}],
 "next_steps": ["ordered, concrete steps"]}
Calibration: score honestly against the rubric for this level. Competent drafts usually land 70-85; 86-92 is strong; 93+ only for work ready to submit with distinction. Quotes must be copied exactly from the paper. 3-6 criteria, 2-4 strengths, 3-7 concerns.`;

async function runAppraisal(focus = '') {
  if (state.busy || !requireEngine()) return;
  const content = state.content.trim();
  if (!content) { showToast('The paper is empty. Import a document or write first.'); return; }
  dom.evaluatorPanel.classList.remove('collapsed');
  selectTab('feed');
  setBusy('Reading and grading your paper…');
  const stacks = await dbGetAll('stacks');
  const paper = content.length > 60000 ? content.slice(0, 60000) + '\n[…the rest of the paper was not included because of length…]' : content;
  try {
    const r = await callChat({
      system: `You are Artificience, a rigorous, fair university evaluator.\n${contextBlock(stacks)}\n\n${APPRAISAL_SCHEMA}`,
      user: `${focus ? 'Focus of this appraisal: ' + focus + '\n\n' : ''}Paper title: ${state.title || 'Untitled'}\n\nPAPER:\n"""\n${paper}\n"""`,
      images: state.attachedImages, maxTokens: 1800, json: true
    });
    const result = parseJSON(r.text);
    if (!result || typeof result.score !== 'number') throw new Error('The evaluator’s answer could not be read. Try again, or try a different model.');
    state.appraisals.unshift({ at: new Date().toISOString(), framework: state.activeFramework, result });
    persistDocument();
    renderAppraisalFeed();
    showToast('Appraisal complete.');
  } catch (err) {
    if (err.name !== 'AbortError') errorCard(err.message);
  } finally { setBusy(''); }
}
function errorCard(message) {
  const card = document.createElement('div');
  card.className = 'eval-card error-card';
  card.innerHTML = `<div class="eval-card-body"><strong>Couldn’t finish.</strong> ${escapeHTML(message)}</div>`;
  dom.feed.prepend(card);
  selectTab('feed');
}
function scoreWord(s) { return s >= 93 ? 'Distinguished' : s >= 86 ? 'Strong' : s >= 78 ? 'Proficient' : s >= 70 ? 'Developing' : 'Needs work'; }
function renderAppraisalFeed() {
  dom.feed.querySelectorAll('.eval-card.appraisal, .chat-card').forEach(c => c.remove());
  const intro = $('intro-card');
  if (intro) intro.classList.toggle('hidden', state.appraisals.length > 0);
  const names = LENS_NAMES();
  state.appraisals.slice(0, 5).reverse().forEach((a, idx, arr) => {
    const r = a.result, latest = idx === arr.length - 1;
    const card = document.createElement('div');
    card.className = 'eval-card appraisal' + (latest ? '' : ' older');
    card.innerHTML = `
      <div class="eval-card-header">
        <span class="eval-lens-tag">✦ ${escapeHTML((names[a.framework] || a.framework).toUpperCase())}</span>
        <span class="eval-scholar-tag">${fmtDate(a.at)}</span>
      </div>
      <div class="grade-matrix-chassis">
        <div class="grade-dial-col"><span class="grade-num">${Math.round(r.score)}</span><span class="grade-label">${escapeHTML(scoreWord(r.score).toUpperCase())}</span></div>
        <div class="grade-meters-col">${(r.criteria || []).map(c => `
          <div class="meter-row" title="${escapeHTML(c.comment || '')}">
            <div class="meter-meta"><span>${escapeHTML(c.name)}</span><strong>${Math.round(c.score)}</strong></div>
            <div class="meter-groove"><div class="meter-needle" style="width:${Math.max(0, Math.min(100, c.score))}%"></div></div>
          </div>`).join('')}
        </div>
      </div>
      <div class="eval-card-body">
        <p class="appraisal-standing">${escapeHTML(r.standing || '')}</p>
        <p>${escapeHTML(r.summary || '')}</p>
        ${(r.criteria || []).length ? `<details class="appraisal-section"><summary>Criteria notes</summary>${r.criteria.map(c => `<p><strong>${escapeHTML(c.name)} · ${Math.round(c.score)}</strong> — ${escapeHTML(c.comment || '')}</p>`).join('')}</details>` : ''}
        ${(r.strengths || []).length ? `<div class="appraisal-section"><h4>Strengths</h4>${r.strengths.map(s => `<p class="point good">${escapeHTML(s.point)}${s.quote ? ` <button class="quote-link" data-quote="${escapeHTML(s.quote)}">“${escapeHTML(s.quote.slice(0, 70))}${s.quote.length > 70 ? '…' : ''}”</button>` : ''}</p>`).join('')}</div>` : ''}
        ${(r.concerns || []).length ? `<div class="appraisal-section"><h4>Concerns</h4>${r.concerns.map((c, i) => `
          <div class="concern ${c.severity === 'major' ? 'major' : ''}">
            <p><span class="sev">${c.severity === 'major' ? 'Major' : 'Minor'}</span> ${escapeHTML(c.issue)}</p>
            ${c.quote ? `<button class="quote-link" data-quote="${escapeHTML(c.quote)}">“${escapeHTML(c.quote.slice(0, 80))}${c.quote.length > 80 ? '…' : ''}”</button>` : ''}
            <p class="suggest">${escapeHTML(c.suggestion || '')}</p>
            ${latest ? `<button class="btn-mini" data-fix="${i}">Suggest edits for this</button>` : ''}
          </div>`).join('')}</div>` : ''}
        ${(r.next_steps || []).length ? `<div class="appraisal-section"><h4>Next steps</h4><ol>${r.next_steps.map(s => `<li>${escapeHTML(s)}</li>`).join('')}</ol></div>` : ''}
        ${latest ? `<div class="artifact-actions">
          <button class="btn-adopt" data-act="revise-concerns">✦ Turn concerns into revisions</button>
          <button class="btn-download" data-act="report">Save as report</button>
        </div>` : ''}
      </div>`;
    dom.feed.prepend(card);
    card.querySelectorAll('.quote-link').forEach(b => b.addEventListener('click', () => revealQuote(b.dataset.quote)));
    card.querySelectorAll('[data-fix]').forEach(b => b.addEventListener('click', () => {
      const c = r.concerns[+b.dataset.fix];
      const range = c.quote ? paragraphAround(c.quote) : null;
      runRevisions({ focus: `${c.issue} — ${c.suggestion}`, range });
    }));
    card.querySelector('[data-act="revise-concerns"]')?.addEventListener('click', () => runRevisions({ focus: 'Address these appraisal concerns first: ' + (r.concerns || []).map(c => `${c.issue} (${c.suggestion})`).join('; ') }));
    card.querySelector('[data-act="report"]')?.addEventListener('click', () => makeDocument('report'));
  });
}
function revealQuote(quote) {
  if (state.review) { showToast('Close the revision review to jump to passages.'); return; }
  // Switching to the paper first makes quoted appraisal feedback navigable on phones.
  if (window.ArtificienceMobile?.isMobile()) window.ArtificienceMobile.open('paper');
  if (!RichEditor.reveal(quote)) showToast('That passage has changed since the appraisal.');
}
function paragraphAround(quote) {
  const pos = locate(state.content, quote);
  if (!pos) return null;
  const start = state.content.lastIndexOf('\n\n', pos[0]);
  const end = state.content.indexOf('\n\n', pos[1]);
  return { start: start < 0 ? 0 : start + 2, end: end < 0 ? state.content.length : end };
}

// ───────────────────────── Revisions: request → tracked changes in the paper ─────────────────────────
const INTENSITY = {
  light: { per: 4, rule: 'Only essential fixes: errors, unclear claims, unsupported assertions, broken logic.' },
  standard: { per: 8, rule: 'Essential and recommended improvements.' },
  thorough: { per: 12, rule: 'Essential, recommended and worthwhile optional refinements.' }
};
const FOCUS_AREAS = { 'Argument': ['Argument'], 'Evidence & citations': ['Evidence', 'Citation'], 'Structure & flow': ['Structure', 'Transition'], 'Style & tone': ['Tone'], 'Clarity & concision': ['Clarity', 'Concision'], 'Grammar & mechanics': ['Grammar'] };
function focusCategories() { return (state.settings.focus || []).flatMap(f => FOCUS_AREAS[f] || []); }
function revisionSystem(stacks) {
  const depth = INTENSITY[state.settings.intensity] || INTENSITY.standard;
  return `You are Artificience, a scholarly editor reviewing one section of a paper. You propose specific, tracked edits the author will accept or reject one by one.
${contextBlock(stacks)}

Return one JSON object:
{"edits": [{"type": "replace" | "insert" | "delete",
            "quote": "text copied EXACTLY, character for character, from the SECTION. For replace/delete: the words to change (a phrase or 1-2 sentences, never a whole long paragraph). For insert: the sentence the new text goes after.",
            "text": "the replacement, or the new text to insert (empty string for delete)",
            "new_paragraph": true | false,
            "category": "Argument" | "Evidence" | "Citation" | "Clarity" | "Concision" | "Structure" | "Transition" | "Tone" | "Grammar",
            "strength": "essential" | "recommended" | "optional",
            "why": "one or two specific sentences on what this fixes and why it serves the paper"}],
 "not_recommended": [{"idea": "a tempting change or addition the author should NOT make here", "why": "why it would weaken the paper"}]}

Rules:
- ${depth.rule} At most ${depth.per} edits for this section; quality over quantity. Return no edit rather than a cosmetic one.${focusCategories().length ? `\n- Only propose edits in these categories: ${focusCategories().join(', ')}.` : ''}
- Keep the author's voice, thesis and coined terms. Improve the argument, evidence, structure and precision rather than paraphrasing for its own sake.
- Use "insert" for genuinely missing material: a counter-argument, a transition, a definition the reader needs, an example, or a needed citation.
- Never invent sources, page numbers, data or quotations. Where evidence or a citation is needed, insert a bracketed placeholder such as [citation needed: empirical study of X].
- Edits must not overlap one another.
- 0-3 not_recommended items: changes a less careful editor might suggest that would flatten the author's distinctive thinking, over-explain, or pad the paper.`;
}
function splitSections(text, start, end, size = 4500) {
  const sections = [];
  let i = start;
  while (i < end) {
    let j = Math.min(end, i + size);
    if (j < end) { const br = text.lastIndexOf('\n\n', j); if (br > i + size * 0.4) j = br; }
    sections.push({ start: i, end: j });
    i = j;
  }
  return sections;
}
function toEdit(raw, text, sec, seq) {
  const type = ['replace', 'insert', 'delete'].includes(raw.type) ? raw.type : 'replace';
  const pos = locate(text, raw.quote, sec.start, sec.end);
  if (!pos) return null;
  const replacement = String(raw.text ?? '');
  let start = pos[0], end = pos[1], insertText = replacement;
  if (type === 'insert') {
    if (!replacement.trim()) return null;
    start = end;
    insertText = raw.new_paragraph ? '\n\n' + replacement.trim() : ' ' + replacement.trim();
  } else if (type === 'delete') {
    insertText = '';
    // take one neighbouring space with the cut so no double or trailing space is left behind
    if (text[end] === ' ') end++; else if (text[start - 1] === ' ') start--;
  }
  else if (replacement === text.slice(start, end)) return null;
  return {
    id: 'rev_' + Date.now().toString(36) + '_' + seq,
    type, start, end,
    original: text.slice(start, end),
    replacement: insertText,
    category: String(raw.category || 'Clarity').slice(0, 20),
    strength: ['essential', 'recommended', 'optional'].includes(raw.strength) ? raw.strength : 'recommended',
    why: String(raw.why || '').slice(0, 400),
    status: 'pending'
  };
}
function overlaps(a, b) { return a.start < b.end && b.start < a.end || (a.start === a.end && a.start === b.start) || (b.start === b.end && b.start === a.start && a.start !== a.end && false); }

async function runRevisions({ focus = '', range = null } = {}) {
  if (state.busy || !requireEngine()) return;
  if (!state.content.trim()) { showToast('The paper is empty. Import a document or write first.'); return; }
  if (state.review && state.review.edits.some(e => e.status === 'pending')) {
    if (!confirm('A revision review is already open. Replace it with new suggestions?')) return;
  }
  const text = state.content;
  const scope = range || { start: 0, end: text.length };
  const sections = splitSections(text, scope.start, scope.end);
  const stacks = await dbGetAll('stacks');
  state.review = { edits: [], notRecommended: [], scope, focus, createdAt: new Date().toISOString(), sectionsDone: 0, sectionsTotal: sections.length, baseText: text, unplaced: 0 };
  state.undoStack = [];
  dom.evaluatorPanel.classList.remove('collapsed');
  openReview(); selectTab('revisions');
  let seq = 0;
  try {
    for (let s = 0; s < sections.length; s++) {
      const sec = sections[s];
      setBusy(sections.length > 1 ? `Reading section ${s + 1} of ${sections.length}…` : 'Reading your paper…');
      const r = await callChat({
        system: revisionSystem(stacks),
        user: `${focus ? 'The author asks you to focus on: ' + focus + '\n\n' : ''}Paper title: ${state.title || 'Untitled'}\n${sections.length > 1 ? `(Section ${s + 1} of ${sections.length}.)\n` : ''}\nSECTION:\n"""\n${text.slice(sec.start, sec.end)}\n"""`,
        maxTokens: 2400, json: true
      });
      const out = parseJSON(r.text) || {};
      for (const raw of Array.isArray(out.edits) ? out.edits : []) {
        const e = toEdit(raw, text, sec, seq++);
        if (!e) { state.review.unplaced++; continue; }
        if (state.review.edits.some(x => x.start < e.end && e.start < x.end || (x.start === x.end && e.start === e.end && x.start === e.start))) { state.review.unplaced++; continue; }
        state.review.edits.push(e);
      }
      for (const n of Array.isArray(out.not_recommended) ? out.not_recommended : []) if (n && n.idea) state.review.notRecommended.push({ idea: String(n.idea), why: String(n.why || '') });
      state.review.edits.sort((a, b) => a.start - b.start || (a.end - a.start) - (b.end - b.start));
      state.review.sectionsDone = s + 1;
      renderReviewStage(); renderLedger();
    }
    persistDocument();
    const n = state.review.edits.length;
    if (!n) { showToast('No changes proposed. The evaluator found nothing worth changing at this depth.'); }
    else { showToast(`✦ ${n} revision${n === 1 ? '' : 's'} marked in your paper.`); focusEdit(0); }
  } catch (err) {
    if (err.name !== 'AbortError') { showToast(err.message, 6000); if (!state.review.edits.length) { state.review = null; closeReviewView(); } }
  } finally { setBusy(''); renderLedger(); renderReviewStage(); persistDocument(); }
}

// Review view: the paper with each change marked in place
function openReview() {
  hide(dom.editor); hide($('rt-toolbar-host')); show(dom.stage); show(dom.banner);
  renderReviewStage();
}
function closeReviewView() { show(dom.editor); show($('rt-toolbar-host')); hide(dom.stage); hide(dom.banner); dom.stage.innerHTML = ''; }
const CAT_ICON = { Argument: '⚖︎', Evidence: '◆', Citation: '❝', Clarity: '◎', Concision: '✂︎', Structure: '☰', Transition: '↝', Tone: '♪', Grammar: '¶' };
function stageText(t) {
  return escapeHTML(t)
    .replace(/^(#{1,3}) (.*)$/gm, (m, h, x) => `<span class="stage-h stage-h${h.length}">${x}</span>`)
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
}
function renderReviewStage() {
  const rv = state.review;
  if (!rv) return;
  const text = rv.baseText;
  let html = '', at = 0;
  rv.edits.forEach((e, idx) => {
    if (e.start > at) html += stageText(text.slice(at, e.start));
    const n = idx + 1;
    const del = e.original ? `<del class="diff-del">${escapeHTML(e.original)}</del>` : '';
    const ins = e.replacement ? `<ins class="diff-ins ${e.type === 'insert' ? 'addition' : ''}">${escapeHTML(e.replacement)}</ins>` : '';
    let body;
    if (e.status === 'accepted') body = e.replacement ? `<ins class="diff-ins kept">${escapeHTML(e.replacement)}</ins>` : `<span class="removed-mark" title="Removed">⌫</span>`;
    else if (e.status === 'rejected') body = `<span class="restored">${escapeHTML(e.original)}</span>`;
    else body = del + ins;
    html += `<span class="rev rev-${e.status} strength-${e.strength}" id="${e.id}" data-idx="${idx}"><sup class="rev-num">${n}</sup>${body}<span class="rev-tools">${e.status === 'pending'
      ? `<button class="btn-chunk-check" data-keep="${idx}" title="Keep this change (Y)">✓</button><button class="btn-chunk-cross" data-reject="${idx}" title="Reject this change (N)">✕</button>`
      : `<button class="btn-chunk-undo" data-reset="${idx}" title="Change my decision">↺</button>`}</span></span>`;
    at = Math.max(at, e.end);
  });
  html += stageText(text.slice(at));
  const working = state.busy && rv.sectionsDone < rv.sectionsTotal ? `<div class="stage-working"><span class="diode-dot"></span> Reading section ${rv.sectionsDone + 1} of ${rv.sectionsTotal}… changes appear as each section is read.</div>` : '';
  dom.stage.innerHTML = working + `<div class="stage-text">${html}</div>`;
  dom.stage.querySelectorAll('[data-keep]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); decide(+b.dataset.keep, 'accepted'); }));
  dom.stage.querySelectorAll('[data-reject]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); decide(+b.dataset.reject, 'rejected'); }));
  dom.stage.querySelectorAll('[data-reset]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); decide(+b.dataset.reset, 'pending'); }));
  dom.stage.querySelectorAll('.rev').forEach(s => s.addEventListener('click', () => focusEdit(+s.dataset.idx, true)));
  if (state.reviewCursor >= 0) markCursor();
  updateProgress();
}
function updateProgress() {
  const rv = state.review; if (!rv) return;
  const total = rv.edits.length, decided = rv.edits.filter(e => e.status !== 'pending').length, kept = rv.edits.filter(e => e.status === 'accepted').length;
  dom.reviewProgress.textContent = total ? `${decided} of ${total} decided · ${kept} kept` : (state.busy ? 'Reading…' : 'No changes proposed');
  dom.reviewFill.style.width = total ? `${(decided / total) * 100}%` : '0%';
  dom.revisionsCount.textContent = total;
}
function decide(idx, status, quiet = false) {
  const e = state.review?.edits[idx];
  if (!e || e.status === status) return;
  state.undoStack.push({ idx, prev: e.status, prevReplacement: e.replacement });
  e.status = status;
  renderReviewStage(); renderLedger();
  persistDocument();
  if (!quiet && status !== 'pending') {
    const next = state.review.edits.findIndex((x, i) => i > idx && x.status === 'pending');
    if (next >= 0) focusEdit(next); else { const any = state.review.edits.findIndex(x => x.status === 'pending'); if (any >= 0) focusEdit(any); else showToast('All changes decided. Choose “Apply my decisions”.'); }
  }
}
function undoDecision() {
  const u = state.undoStack.pop(); if (!u) return;
  const e = state.review.edits[u.idx];
  e.status = u.prev; e.replacement = u.prevReplacement;
  renderReviewStage(); renderLedger(); focusEdit(u.idx); persistDocument();
}
function markCursor() {
  dom.stage.querySelectorAll('.rev.cursor').forEach(x => x.classList.remove('cursor'));
  dom.ledger.querySelectorAll('.ledger-card.cursor').forEach(x => x.classList.remove('cursor'));
  const e = state.review?.edits[state.reviewCursor]; if (!e) return;
  $(e.id)?.classList.add('cursor');
  dom.ledger.querySelector(`[data-card="${state.reviewCursor}"]`)?.classList.add('cursor');
}
function focusEdit(idx, fromStage = false) {
  const e = state.review?.edits[idx]; if (!e) return;
  state.reviewCursor = idx; markCursor();
  const span = $(e.id); if (span && !fromStage) span.scrollIntoView({ block: 'center', behavior: 'smooth' });
  const card = dom.ledger.querySelector(`[data-card="${idx}"]`);
  if (card) card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  if (fromStage) selectTab('revisions');
}
function finalText() {
  const rv = state.review;
  let text = rv.baseText;
  [...rv.edits].filter(e => e.status === 'accepted').sort((a, b) => b.start - a.start).forEach(e => { text = text.slice(0, e.start) + e.replacement + text.slice(e.end); });
  return text.replace(/\n{3,}/g, '\n\n');
}
async function applyDecisions() {
  const rv = state.review; if (!rv) return;
  if (state.busy) { showToast('Wait for the evaluator to finish reading.'); return; }
  const pending = rv.edits.filter(e => e.status === 'pending').length;
  if (pending && !confirm(`${pending} change${pending === 1 ? ' is' : 's are'} still undecided. Treat ${pending === 1 ? 'it' : 'them'} as rejected and apply your decisions?`)) return;
  rv.edits.forEach(e => { if (e.status === 'pending') e.status = 'rejected'; });
  await dbSave('versions', { id: 'ver_' + Date.now(), docId: state.currentDocId, title: state.title, content: rv.baseText, html: RichEditor.getHtml(), docStyle: RichEditor.getDocStyle(), createdAt: new Date().toISOString(), note: 'Before applying revisions' });
  const kept = rv.edits.filter(e => e.status === 'accepted').length;
  const keptEdits = rv.edits.filter(e => e.status === 'accepted');
  // Write each kept change into the page in place; if one can't be placed, rebuild changed paragraphs instead.
  if (keptEdits.length && !RichEditor.applyEdits(keptEdits, rv.baseText)) RichEditor.applyMarkdownPreservingFormat(finalText());
  state.lastReview = { ...rv, appliedAt: new Date().toISOString(), baseText: undefined };
  state.review = null; state.reviewCursor = -1;
  closeReviewView(); handleEditorInput(); renderLedger(); await persistDocument();
  showToast(`Applied ${kept} change${kept === 1 ? '' : 's'}. The previous version is saved under Papers → Restore.`, 4000);
}
function cancelReview() {
  if (!state.review) return;
  if (state.review.edits.some(e => e.status !== 'pending') && !confirm('Close the review and discard your decisions? Your paper stays as it was.')) return;
  state.abort?.abort();
  state.review = null; state.reviewCursor = -1;
  closeReviewView(); renderLedger(); persistDocument();
}

// The ledger: every change with its reason, plus what not to add
function renderLedger() {
  const rv = state.review;
  if (!rv) {
    dom.revisionsCount.textContent = '0';
    const last = state.lastReview;
    dom.ledger.innerHTML = `<div class="empty-state">No revisions open. Choose <strong>Suggest Scholarly Revisions</strong> for the whole paper, or select a passage and choose <strong>Revise selection</strong>.</div>` +
      (last ? `<div class="ledger-last">Last review: ${last.edits.filter(e => e.status === 'accepted').length} of ${last.edits.length} changes kept on ${fmtDate(last.appliedAt)}. <button class="btn-mini" id="btn-last-memo">Create revision memo</button></div>` : '');
    $('btn-last-memo')?.addEventListener('click', () => makeDocument('memo'));
    return;
  }
  const filter = dom.ledger.dataset.filter || 'all';
  const counts = { essential: 0, recommended: 0, optional: 0 };
  rv.edits.forEach(e => counts[e.strength]++);
  const cats = [...new Set(rv.edits.map(e => e.category))];
  const visible = rv.edits.map((e, i) => [e, i]).filter(([e]) => filter === 'all' || filter === e.strength || filter === e.category || (filter === 'pending' && e.status === 'pending'));
  dom.ledger.innerHTML = `
    <div class="ledger-head">
      <div><strong>${rv.edits.length} proposed change${rv.edits.length === 1 ? '' : 's'}</strong>${rv.scope.start > 0 || rv.scope.end < rv.baseText.length ? ' · selected passage' : ''}${rv.focus ? `<div class="ledger-focus">Focus: ${escapeHTML(rv.focus.slice(0, 160))}${rv.focus.length > 160 ? '…' : ''}</div>` : ''}</div>
      ${state.busy ? '<span class="ledger-working"><span class="diode-dot"></span> reading</span>' : ''}
    </div>
    <div class="ledger-filters">
      ${[['all', 'All'], ['pending', 'Undecided'], ['essential', `Essential ${counts.essential}`], ['recommended', `Recommended ${counts.recommended}`], ['optional', `Optional ${counts.optional}`], ...cats.map(c => [c, c])].map(([k, l]) => `<button class="ledger-chip ${filter === k ? 'active' : ''}" data-filter="${escapeHTML(k)}">${escapeHTML(l)}</button>`).join('')}
    </div>
    ${visible.map(([e, i]) => `
      <div class="ledger-card status-${e.status} strength-${e.strength}" data-card="${i}">
        <div class="ledger-card-top">
          <span class="ledger-num">${i + 1}</span>
          <span class="ledger-cat">${CAT_ICON[e.category] || '✦'} ${escapeHTML(e.category)}</span>
          <span class="ledger-strength">${e.strength}</span>
          <span class="ledger-type">${e.type === 'insert' ? 'Addition' : e.type === 'delete' ? 'Cut' : 'Rewrite'}</span>
        </div>
        <p class="ledger-why">${escapeHTML(e.why || 'No reason given.')}</p>
        ${e.original ? `<div class="ledger-before"><span>Before</span>${escapeHTML(e.original.length > 220 ? e.original.slice(0, 220) + '…' : e.original)}</div>` : ''}
        ${e.status === 'pending' && state.editingIdx === i
          ? `<textarea class="ledger-edit" data-editbox="${i}">${escapeHTML(e.replacement.trim())}</textarea><div class="ledger-actions"><button class="btn-mini" data-saveedit="${i}">Save wording</button><button class="btn-mini ghost" data-canceledit="${i}">Cancel</button></div>`
          : e.replacement.trim() ? `<div class="ledger-after"><span>${e.type === 'insert' ? 'Add' : 'After'}</span>${escapeHTML(e.replacement.trim())}</div>` : `<div class="ledger-after cut"><span>After</span>(removed)</div>`}
        <div class="ledger-actions">
          ${e.status === 'pending' ? `
            <button class="btn-chunk-check" data-keep="${i}">✓ Keep</button>
            <button class="btn-chunk-cross" data-reject="${i}">✕ Reject</button>
            ${e.replacement.trim() ? `<button class="btn-mini ghost" data-edit="${i}">✎ Adjust wording</button>` : ''}`
          : `<span class="ledger-decision">${e.status === 'accepted' ? '✓ Kept' : '✕ Rejected'}</span><button class="btn-mini ghost" data-reset="${i}">↺ Change</button>`}
        </div>
      </div>`).join('')}
    ${!visible.length && rv.edits.length ? '<div class="empty-state">No changes match this filter.</div>' : ''}
    ${!rv.edits.length && !state.busy ? '<div class="empty-state">No changes proposed at this depth. Try “Thorough” in Settings, or ask for something specific in Revise paper mode.</div>' : ''}
    ${rv.unplaced ? `<p class="ledger-note">${rv.unplaced} suggestion${rv.unplaced === 1 ? '' : 's'} couldn’t be matched to your exact wording and ${rv.unplaced === 1 ? 'was' : 'were'} left out, so nothing was changed by guesswork.</p>` : ''}
    ${rv.notRecommended.length ? `
      <div class="not-recommended">
        <h4>Considered — and advised against</h4>
        <p class="ledger-note">Changes that might look like improvements but would weaken this paper.</p>
        ${rv.notRecommended.map(n => `<div class="nr-item"><span class="nr-x">⊘</span><div><strong>${escapeHTML(n.idea)}</strong><p>${escapeHTML(n.why)}</p></div></div>`).join('')}
      </div>` : ''}`;
  dom.ledger.querySelectorAll('[data-filter]').forEach(b => b.addEventListener('click', () => { dom.ledger.dataset.filter = b.dataset.filter; renderLedger(); }));
  dom.ledger.querySelectorAll('[data-keep]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); decide(+b.dataset.keep, 'accepted'); }));
  dom.ledger.querySelectorAll('[data-reject]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); decide(+b.dataset.reject, 'rejected'); }));
  dom.ledger.querySelectorAll('[data-reset]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); decide(+b.dataset.reset, 'pending', true); }));
  dom.ledger.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); state.editingIdx = +b.dataset.edit; renderLedger(); dom.ledger.querySelector('.ledger-edit')?.focus(); }));
  dom.ledger.querySelectorAll('[data-canceledit]').forEach(b => b.addEventListener('click', (ev) => { ev.stopPropagation(); state.editingIdx = null; renderLedger(); }));
  dom.ledger.querySelectorAll('[data-saveedit]').forEach(b => b.addEventListener('click', (ev) => {
    ev.stopPropagation();
    const i = +b.dataset.saveedit, e = rv.edits[i], box = dom.ledger.querySelector(`[data-editbox="${i}"]`);
    const val = box.value.trim();
    state.undoStack.push({ idx: i, prev: e.status, prevReplacement: e.replacement });
    e.replacement = e.type === 'insert' ? (e.replacement.startsWith('\n\n') ? '\n\n' : ' ') + val : val;
    e.edited = true; state.editingIdx = null;
    renderReviewStage(); renderLedger(); persistDocument();
  }));
  dom.ledger.querySelectorAll('[data-card]').forEach(c => c.addEventListener('click', (ev) => { if (ev.target.closest('button,textarea')) return; focusEdit(+c.dataset.card); }));
  markCursor();
  updateProgress();
}

// ───────────────────────── Selection revisions & directives ─────────────────────────
function captureSelection() {
  if (state.review) return;
  const t = RichEditor.selectedText().trim();
  const pos = t.length > 3 ? locate(state.content, t) : null;
  state.selection = pos ? { start: pos[0], end: pos[1], text: state.content.slice(pos[0], pos[1]) } : (t.length > 3 ? { start: 0, end: 0, text: t, unmatched: true } : null);
  updateSelectionButton();
}
function updateSelectionButton() {
  dom.btnReviseSel = $('btn-revise-selection'); if (!dom.btnReviseSel) return;
  dom.btnReviseSel.disabled = state.busy || !!state.review || !state.selection;
  dom.btnReviseSel.title = state.selection ? `Revise the ${words(state.selection.text)} selected words` : 'Select a passage in your paper first';
  if (state.mode === 'revise') dom.modeHint.textContent = state.selection ? `Applies to your ${words(state.selection.text)}-word selection` : 'Applies to the whole paper';
}
function selectionRange() {
  const s = state.selection; if (!s || s.unmatched) return null;
  // widen to whole sentences so quoted passages match cleanly
  const t = state.content;
  let a = s.start, b = s.end;
  while (a > 0 && !/[.!?\n]/.test(t[a - 1])) a--;
  while (b < t.length && !/[.!?\n]/.test(t[b - 1] || '')) b++;
  return { start: Math.max(0, a), end: Math.min(t.length, b) };
}
function openPrompt({ title, sub, placeholder = '', chips = [], value = '', onGo }) {
  $('prompt-title').textContent = title; $('prompt-sub').textContent = sub || '';
  const input = $('prompt-input'); input.value = value; input.placeholder = placeholder;
  $('prompt-chips').innerHTML = chips.map(c => `<button class="ledger-chip" data-chip="${escapeHTML(c)}">${escapeHTML(c)}</button>`).join('');
  $('prompt-chips').querySelectorAll('[data-chip]').forEach(b => b.addEventListener('click', () => { input.value = b.dataset.chip; input.focus(); }));
  show($('modal-prompt')); setTimeout(() => input.focus(), 30);
  $('btn-prompt-go').onclick = () => { const v = input.value.trim(); hide($('modal-prompt')); onGo(v); };
}
const SELECTION_CHIPS = ['Tighten and remove padding', 'Strengthen the argument', 'Mark where evidence or citations are needed', 'Add a counter-argument and response', 'Make the transition clearer', 'Raise to formal scholarly register'];
function reviseSelection() {
  captureSelection();
  if (!state.selection) { showToast('Highlight a passage in your paper first.'); return; }
  if (state.selection.unmatched) { showToast('That selection spans formatting the evaluator can’t match. Select within one or two paragraphs.', 4500); return; }
  const range = selectionRange(), n = words(state.selection.text);
  openPrompt({
    title: 'Revise this passage', sub: `${n} selected words. Changes appear in the paper for you to keep or reject.`,
    placeholder: 'What should improve? (optional)', chips: SELECTION_CHIPS,
    onGo: (v) => runRevisions({ focus: v || 'Improve this passage', range })
  });
}
async function askEvaluator(question) {
  if (state.busy || !requireEngine()) return;
  dom.evaluatorPanel.classList.remove('collapsed'); selectTab('feed');
  $('intro-card')?.classList.add('hidden');
  const card = document.createElement('div');
  card.className = 'eval-card chat-card';
  card.innerHTML = `<div class="chat-q">${escapeHTML(question)}</div><div class="eval-card-body md-body"><span class="diode-dot"></span></div>`;
  dom.feed.prepend(card);
  const body = card.querySelector('.md-body');
  setBusy('The evaluator is answering…');
  const stacks = await dbGetAll('stacks');
  try {
    const paper = state.content.slice(0, 40000);
    const r = await callChat({
      system: `You are Artificience, a rigorous, fair university evaluator answering the scholar's question about their paper. Be specific: quote the paper where it helps. Use short Markdown sections or lists when useful.\n${contextBlock(stacks)}`,
      user: `${paper ? `PAPER (${state.title || 'Untitled'}):\n"""\n${paper}\n"""\n\n` : ''}QUESTION: ${question}`,
      images: state.attachedImages, maxTokens: 1400, stream: true, temperature: 0.5,
      onDelta: (t) => { body.innerHTML = mdToHtml(t); }
    });
    body.innerHTML = mdToHtml(r.text) + (r.truncated ? '<p class="ledger-note">The answer reached its length limit.</p>' : '');
    const actions = document.createElement('div');
    actions.className = 'artifact-actions';
    actions.innerHTML = `<button class="btn-download">Save as document</button><button class="btn-adopt">✦ Turn into revisions</button>`;
    body.appendChild(actions);
    actions.querySelector('.btn-download').addEventListener('click', () => saveArtifact({ title: 'Evaluator answer: ' + question.slice(0, 60), kind: 'answer', content: `## ${question}\n\n${r.text}` }).then(a => { showToast('Saved to Documents.'); openDocModal(a); }));
    actions.querySelector('.btn-adopt').addEventListener('click', () => runRevisions({ focus: `${question} — apply this guidance: ${r.text.slice(0, 1500)}` }));
  } catch (err) {
    if (err.name !== 'AbortError') body.innerHTML = `<span class="error-text">${escapeHTML(err.message)}</span>`;
  } finally { setBusy(''); }
}
function setMode(mode) {
  state.mode = mode;
  $('mode-ask').classList.toggle('active', mode === 'ask');
  $('mode-revise').classList.toggle('active', mode === 'revise');
  dom.directive.placeholder = mode === 'ask' ? 'Ask the evaluator (e.g. ‘Is my thesis arguable?’)…' : 'Describe the revision (e.g. ‘Add a counter-argument to section 2’)…';
  dom.modeHint.textContent = mode === 'ask' ? 'Answers appear here' : '';
  updateSelectionButton();
}
function sendDirective() {
  const v = dom.directive.value.trim(); if (!v) return;
  dom.directive.value = '';
  if (state.mode === 'revise') runRevisions({ focus: v, range: state.selection ? selectionRange() : null });
  else askEvaluator(v);
}

// ───────────────────────── Markdown → blocks → HTML / Word / text ─────────────────────────
function inlineRuns(text) {
  const runs = [], re = /(\*\*[^*]+\*\*|\*[^*\s][^*]*\*|_[^_\s][^_]*_)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) runs.push({ text: text.slice(last, m.index) });
    const t = m[0];
    runs.push(t.startsWith('**') ? { text: t.slice(2, -2), bold: true } : { text: t.slice(1, -1), italics: true });
    last = m.index + t.length;
  }
  if (last < text.length) runs.push({ text: text.slice(last) });
  return runs.length ? runs : [{ text }];
}
function mdToBlocks(md) {
  const blocks = [];
  const chunks = String(md || '').replace(/\r\n?/g, '\n').split(/\n{2,}/);
  for (const chunk of chunks) {
    const lines = chunk.split('\n').filter(l => l.trim() !== '');
    if (!lines.length) continue;
    if (lines.every(l => /^\s*([-*•]|\d+[.)])\s+/.test(l))) {
      lines.forEach(l => blocks.push({ type: /^\s*\d/.test(l) ? 'ol' : 'ul', text: l.replace(/^\s*([-*•]|\d+[.)])\s+/, '') }));
      continue;
    }
    if (lines.every(l => /^\s*>/.test(l))) { blocks.push({ type: 'quote', text: lines.map(l => l.replace(/^\s*>\s?/, '')).join(' ') }); continue; }
    if (/^-{3,}$|^\*{3,}$/.test(lines[0].trim()) && lines.length === 1) { blocks.push({ type: 'hr', text: '' }); continue; }
    const h = /^(#{1,3})\s+(.*)$/.exec(lines[0]);
    if (h) {
      blocks.push({ type: 'h' + h[1].length, text: h[2].trim() });
      if (lines.length > 1) blocks.push({ type: 'p', text: lines.slice(1).join('\n') });
      continue;
    }
    if (lines.length > 1 && lines.every(l => /^\s*\|.*\|\s*$/.test(l))) {
      const rows = lines.map(l => l.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim())).filter(r => !r.every(c => /^:?-{2,}:?$/.test(c)));
      blocks.push({ type: 'table', rows }); continue;
    }
    blocks.push({ type: 'p', text: lines.join('\n') });
  }
  return blocks;
}
const runsHtml = (t) => inlineRuns(t).map(r => r.bold ? `<strong>${escapeHTML(r.text)}</strong>` : r.italics ? `<em>${escapeHTML(r.text)}</em>` : escapeHTML(r.text)).join('').replace(/\n/g, '<br>');
function mdToHtml(md) {
  let html = '', list = null;
  for (const b of mdToBlocks(md)) {
    if ((b.type === 'ul' || b.type === 'ol') && list !== b.type) { if (list) html += `</${list}>`; html += `<${b.type}>`; list = b.type; }
    else if (b.type !== 'ul' && b.type !== 'ol' && list) { html += `</${list}>`; list = null; }
    if (b.type === 'ul' || b.type === 'ol') html += `<li>${runsHtml(b.text)}</li>`;
    else if (b.type === 'quote') html += `<blockquote>${runsHtml(b.text)}</blockquote>`;
    else if (b.type === 'hr') html += '<hr>';
    else if (b.type === 'table') html += `<table>${b.rows.map((r, i) => `<tr>${r.map(c => i === 0 ? `<th>${runsHtml(c)}</th>` : `<td>${runsHtml(c)}</td>`).join('')}</tr>`).join('')}</table>`;
    else if (b.type[0] === 'h') html += `<${b.type}>${runsHtml(b.text)}</${b.type}>`;
    else html += `<p>${runsHtml(b.text)}</p>`;
  }
  if (list) html += `</${list}>`;
  return html;
}
function mdToPlain(md) {
  return mdToBlocks(md).map(b => {
    const t = (b.text || '').replace(/\*\*([^*]+)\*\*/g, '$1').replace(/(^|[^*])\*([^*]+)\*/g, '$1$2');
    if (b.type === 'ul') return '• ' + t;
    if (b.type === 'ol') return t;
    if (b.type === 'quote') return '    ' + t;
    if (b.type === 'hr') return '* * *';
    if (b.type === 'table') return b.rows.map(r => r.join('\t')).join('\n');
    if (b.type[0] === 'h') return t.toUpperCase();
    return t;
  }).join('\n\n') + '\n';
}
function exportStyle() {
  return state.settings.exportStyle === 'clean'
    ? { font: 'Georgia', size: 23, line: 336, indent: 0, css: `font-family: Georgia, 'Times New Roman', serif; font-size: 11.5pt; line-height: 1.4;`, pIndent: '0', pGap: '10pt' }
    : { font: 'Times New Roman', size: 24, line: 480, indent: 720, css: `font-family: 'Times New Roman', Times, serif; font-size: 12pt; line-height: 2;`, pIndent: '0.5in', pGap: '0' };
}
function htmlDocument(title, md, subtitle = '') {
  const st = exportStyle();
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHTML(title)}</title><style>
@page { size: letter; margin: 1in; }
body { ${st.css} color: #000; max-width: 6.5in; margin: 0 auto; padding: 0.5in 0; }
h1 { font-size: 16pt; text-align: center; font-weight: bold; margin: 0 0 6pt; line-height: 1.3; }
.subtitle { text-align: center; font-size: 10pt; color: #444; margin: 0 0 24pt; }
h2 { font-size: 13pt; font-weight: bold; margin: 18pt 0 6pt; line-height: 1.3; }
h3 { font-size: 12pt; font-weight: bold; font-style: italic; margin: 14pt 0 4pt; }
p { margin: 0 0 ${st.pGap}; text-indent: ${st.pIndent}; }
li { margin: 0 0 4pt; }
blockquote { margin: 0 0.5in 12pt; text-indent: 0; }
table { border-collapse: collapse; width: 100%; margin: 8pt 0 14pt; font-size: 10.5pt; line-height: 1.35; }
th, td { border: 1px solid #999; padding: 4pt 6pt; text-align: left; vertical-align: top; }
th { background: #f2f2f2; }
hr { border: 0; border-top: 1px solid #999; margin: 18pt 0; }
</style></head><body><h1>${escapeHTML(title)}</h1>${subtitle ? `<p class="subtitle">${escapeHTML(subtitle)}</p>` : ''}${mdToHtml(md)}</body></html>`;
}
async function docxBlob(title, md, subtitle = '') {
  const D = window.docx;
  if (!D) throw new Error('The Word writer did not load.');
  const st = exportStyle();
  const run = (r, extra = {}) => new D.TextRun({ text: r.text, bold: r.bold || extra.bold, italics: r.italics || extra.italics, font: st.font, size: extra.size || st.size });
  const runsFor = (text, extra) => inlineRuns(text).flatMap((r, i) => r.text.split('\n').flatMap((part, j) => [...(j ? [new D.TextRun({ break: 1 })] : []), run({ ...r, text: part }, extra)]));
  const kids = [new D.Paragraph({ alignment: D.AlignmentType.CENTER, spacing: { after: subtitle ? 80 : 360 }, children: [run({ text: title, bold: true }, { size: 32 })] })];
  if (subtitle) kids.push(new D.Paragraph({ alignment: D.AlignmentType.CENTER, spacing: { after: 360 }, children: [run({ text: subtitle }, { size: 20 })] }));
  for (const b of mdToBlocks(md)) {
    if (b.type === 'h1' || b.type === 'h2') kids.push(new D.Paragraph({ heading: D.HeadingLevel.HEADING_1, spacing: { before: 360, after: 120 }, children: runsFor(b.text, { bold: true, size: 26 }) }));
    else if (b.type === 'h3') kids.push(new D.Paragraph({ heading: D.HeadingLevel.HEADING_2, spacing: { before: 240, after: 80 }, children: runsFor(b.text, { bold: true, italics: true }) }));
    else if (b.type === 'ul') kids.push(new D.Paragraph({ bullet: { level: 0 }, spacing: { after: 80 }, children: runsFor(b.text) }));
    else if (b.type === 'ol') kids.push(new D.Paragraph({ numbering: { reference: 'num', level: 0 }, spacing: { after: 80 }, children: runsFor(b.text) }));
    else if (b.type === 'quote') kids.push(new D.Paragraph({ indent: { left: 720, right: 720 }, spacing: { after: 240, line: st.line }, children: runsFor(b.text) }));
    else if (b.type === 'hr') kids.push(new D.Paragraph({ alignment: D.AlignmentType.CENTER, children: [run({ text: '* * *' })] }));
    else if (b.type === 'table') kids.push(new D.Table({ width: { size: 100, type: D.WidthType.PERCENTAGE }, rows: b.rows.map((r, i) => new D.TableRow({ children: r.map(c => new D.TableCell({ children: [new D.Paragraph({ children: runsFor(c, { bold: i === 0, size: 20 }) })] })) })) }), new D.Paragraph({ children: [] }));
    else kids.push(new D.Paragraph({ indent: { firstLine: st.indent }, spacing: { after: st.indent ? 0 : 200, line: st.line }, children: runsFor(b.text) }));
  }
  const file = new D.Document({
    creator: 'Artificience', title,
    numbering: { config: [{ reference: 'num', levels: [{ level: 0, format: D.LevelFormat.DECIMAL, text: '%1.', alignment: D.AlignmentType.START }] }] },
    sections: [{ properties: { page: { margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } }, children: kids }]
  });
  return D.Packer.toBlob(file);
}
function printHtml(html) {
  const frame = document.createElement('iframe');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.appendChild(frame);
  const w = frame.contentWindow;
  w.document.open(); w.document.write(html); w.document.close();
  setTimeout(() => { try { w.focus(); w.print(); } finally { setTimeout(() => frame.remove(), 60000); } }, 350);
}
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}
const safeName = (t) => (String(t || 'Document').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '').replace(/\s+/g, ' ').trim().slice(0, 90) || 'Document');
async function exportMarkdown(title, md, format, subtitle = '') {
  const name = safeName(title);
  try {
    if (format === 'pdf') { printHtml(htmlDocument(title, md, subtitle)); showToast('Choose “Save as PDF” in the print dialog.', 4000); }
    else if (format === 'docx') { downloadBlob(await docxBlob(title, md, subtitle), name + '.docx'); showToast('Downloaded Word document.'); }
    else if (format === 'md') { downloadBlob(new Blob([`# ${title}\n\n${subtitle ? '*' + subtitle + '*\n\n' : ''}${md}\n`], { type: 'text/markdown;charset=utf-8' }), name + '.md'); showToast('Downloaded Markdown.'); }
    else if (format === 'txt') { downloadBlob(new Blob([`${title}\n\n${subtitle ? subtitle + '\n\n' : ''}${mdToPlain(md)}`], { type: 'text/plain;charset=utf-8' }), name + '.txt'); showToast('Downloaded text file.'); }
    else if (format === 'html') { downloadBlob(new Blob([htmlDocument(title, md, subtitle)], { type: 'text/html;charset=utf-8' }), name + '.html'); showToast('Downloaded web page.'); }
  } catch (err) { showToast(`Export failed: ${err.message}`, 5000); }
}
const cell = (v) => String(v ?? '').replace(/\s+/g, ' ').replace(/\|/g, '/').trim();
function mdTable(head, rows) { return [`| ${head.join(' | ')} |`, `| ${head.map(() => '---').join(' | ')} |`, ...rows.map(r => `| ${r.map(cell).join(' | ')} |`)].join('\n'); }
function memoMarkdown(rv) {
  if (!rv) return '';
  const kept = rv.edits.filter(e => e.status === 'accepted'), rejected = rv.edits.filter(e => e.status === 'rejected'), pending = rv.edits.filter(e => e.status === 'pending');
  const row = (e) => [rv.edits.indexOf(e) + 1, `${e.category} · ${e.strength}`, (e.original.trim() || '(addition)').slice(0, 160), (e.replacement.trim() || '(removed)').slice(0, 220), e.why || ''];
  let md = `${kept.length} of ${rv.edits.length} proposed changes kept, ${rejected.length} rejected${pending.length ? `, ${pending.length} undecided` : ''}. Lens: ${LENS_NAMES()[state.activeFramework] || state.activeFramework}.${rv.focus ? `\n\nFocus requested: ${rv.focus}` : ''}`;
  if (kept.length) md += `\n\n## Changes kept\n\n${mdTable(['No.', 'Type', 'Before', 'After', 'Why'], kept.map(row))}`;
  if (rejected.length) md += `\n\n## Changes rejected\n\n${mdTable(['No.', 'Type', 'Before', 'Suggested', 'Why'], rejected.map(row))}`;
  if (pending.length) md += `\n\n## Still undecided\n\n${mdTable(['No.', 'Type', 'Before', 'Suggested', 'Why'], pending.map(row))}`;
  if (rv.notRecommended?.length) md += `\n\n## Considered and advised against\n\n${rv.notRecommended.map(n => `- **${n.idea}** — ${n.why}`).join('\n')}`;
  return md;
}
async function exportPaper(format) {
  if (format === 'json') return exportFullWorkspaceJson();
  if (format === 'academic') return window.Features?.templateExport();
  if (format === 'rtf') return window.Features?.exportRtf();
  if (format === 'tex') return window.Features?.exportTex();
  if (state.review) { showToast('Apply or cancel the open revision review first, so the export matches your decisions.', 4500); return; }
  const title = state.title.trim() || 'Untitled Paper', name = safeName(title);
  try {
    // The paper keeps the fonts, sizes, colors and spacing set on the page.
    if (format === 'pdf') { printHtml(RichEditor.toPrintHtml(title)); showToast('Choose “Save as PDF” in the print dialog.', 4000); return; }
    if (format === 'html') { downloadBlob(new Blob([RichEditor.toPrintHtml(title)], { type: 'text/html;charset=utf-8' }), name + '.html'); showToast('Downloaded web page.'); return; }
    if (format === 'docx' || format === 'docx-track') {
      let appendix = null;
      if (format === 'docx-track') { if (state.lastReview) appendix = '## Appendix: Revision decisions\n\n' + memoMarkdown(state.lastReview); else showToast('No applied revision review yet, so the Word file has the paper only.', 4000); }
      downloadBlob(await RichEditor.toDocx(title, appendix), name + '.docx'); showToast('Downloaded Word document.'); return;
    }
    return exportMarkdown(title, state.content, format);
  } catch (err) { showToast(`Export failed: ${err.message}`, 5000); }
}
async function exportFullWorkspaceJson() {
  await persistDocument();
  const stacks = (await dbGetAll('stacks')).map(({ blob, ...s }) => s);
  const backup = { app: 'Artificience', version: '4.2', exportedAt: new Date().toISOString(), profile: state.profile, manuscripts: await dbGetAll('manuscripts'), stacks, artifacts: await dbGetAll('artifacts'), versions: await dbGetAll('versions') };
  downloadBlob(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }), `Artificience Workspace ${new Date().toISOString().slice(0, 10)}.json`);
  showToast('Exported workspace backup. Import it to restore.');
}

// ───────────────────────── Documents tab ─────────────────────────
const DOC_TASKS = {
  abstract: { title: 'Abstract', task: 'Write a 150-250 word scholarly abstract of this paper: problem, central claim, approach, and contribution. Use only what the paper actually argues. Output only the abstract as one paragraph.' },
  outline: { title: 'Outline', task: 'Produce a hierarchical outline of the paper as it actually stands: thesis, then each section with its main claims and supporting points. Use Markdown headings and bullet lists. Do not invent content.' },
  reverse_outline: { title: 'Reverse outline', task: 'Write a reverse outline: for each paragraph in order, one line stating its actual claim, then flag (in italics) any paragraph that repeats an earlier one, drifts from the thesis, or lacks support. Use a numbered list. End with a two-sentence verdict on the argument\'s structure.' },
  cover_letter: { title: 'Cover letter', task: 'Write a concise, professional submission letter (under 300 words) from the scholar to a professor, committee or editor, introducing this paper: its question, claim and contribution. Leave [Recipient name] and [Course or venue] placeholders. Do not overstate.' },
  bibliography: { title: 'Works cited', task: 'List only the sources this paper actually cites or names. Format them in APA 7th edition (use MLA 9 instead if the paper\'s in-text citations are MLA style). Where details are missing, keep the entry and add [missing: year], [missing: publisher] etc. Never invent sources or details. If no sources are cited, say so in one sentence. Output a Markdown list.' }
};
async function saveArtifact({ title, kind, content }) {
  const a = { id: 'art_' + Date.now(), docId: state.currentDocId, paperTitle: state.title || 'Untitled Paper', title, kind, content, createdAt: new Date().toISOString() };
  await dbSave('artifacts', a);
  await renderArtifactsStack();
  return a;
}
async function makeDocument(kind) {
  if (state.busy) { showToast('Wait for the current task to finish.'); return; }
  selectTab('artifacts');
  const paperTitle = state.title || 'Untitled Paper';
  if (kind === 'clean') {
    if (!state.content.trim()) { showToast('The paper is empty.'); return; }
    const a = await saveArtifact({ title: `${paperTitle} — clean copy`, kind, content: state.content });
    return openDocModal(a);
  }
  if (kind === 'memo') {
    const rv = state.review || state.lastReview;
    if (!rv) { showToast('Run Suggest Scholarly Revisions first; the memo records each change and your decision.', 4500); return; }
    const a = await saveArtifact({ title: `${paperTitle} — revision memo`, kind, content: memoMarkdown(rv) });
    return openDocModal(a);
  }
  if (kind === 'report') {
    const ap = state.appraisals[0];
    if (!ap) { showToast('Running an appraisal first…'); await runAppraisal(); if (!state.appraisals[0]) return; return makeDocument('report'); }
    const r = ap.result;
    const md = `**Overall: ${Math.round(r.score)}/100 — ${r.standing || scoreWord(r.score)}**\n\nLens: ${LENS_NAMES()[ap.framework] || ap.framework} · Level: ${state.profile.tierLabel} · ${fmtDate(ap.at)}\n\n## Summary\n\n${r.summary || ''}\n\n## Criteria\n\n${mdTable(['Criterion', 'Score', 'Comment'], (r.criteria || []).map(c => [c.name, Math.round(c.score), c.comment || '']))}\n\n## Strengths\n\n${(r.strengths || []).map(s => `- ${s.point}${s.quote ? ` (“${s.quote}”)` : ''}`).join('\n')}\n\n## Concerns\n\n${(r.concerns || []).map(c => `- **${c.severity === 'major' ? 'Major' : 'Minor'}:** ${c.issue}${c.quote ? ` (“${c.quote}”)` : ''} — ${c.suggestion || ''}`).join('\n')}\n\n## Next steps\n\n${(r.next_steps || []).map((s, i) => `${i + 1}. ${s}`).join('\n')}`;
    const a = await saveArtifact({ title: `${paperTitle} — evaluation report`, kind, content: md });
    return openDocModal(a);
  }
  if (kind === 'custom') {
    return openPrompt({
      title: 'Create a custom document', sub: 'Describe what you need. It will be based on your current paper.',
      placeholder: 'e.g. A one-page response to my professor’s feedback; discussion questions for my seminar; a conference proposal…',
      chips: ['Response to reviewer feedback', 'Seminar discussion questions', 'Conference proposal (300 words)', 'Annotated thesis statement options', 'Glossary of my key terms', 'Presentation talking points'],
      onGo: (v) => v && generateDocument({ title: v.slice(0, 70), task: `${v}. Base it strictly on the paper. Use Markdown headings and lists where helpful.` }, 'custom')
    });
  }
  const t = DOC_TASKS[kind];
  if (t) return generateDocument(t, kind);
}
async function generateDocument(t, kind) {
  if (!requireEngine()) return;
  if (!state.content.trim()) { showToast('The paper is empty. Import a document or write first.'); return; }
  setBusy(`Creating ${t.title.toLowerCase()}…`);
  const stacks = await dbGetAll('stacks');
  try {
    const r = await callChat({
      system: `You are Artificience, producing a formal academic document from the scholar's paper. Output Markdown only, with no preamble or closing remarks. Never invent facts, sources or quotations.\n${contextBlock(stacks)}`,
      user: `TASK: ${t.task}\n\nPAPER (${state.title || 'Untitled'}):\n"""\n${state.content.slice(0, 50000)}\n"""`,
      maxTokens: 1800, temperature: 0.4
    });
    if (!r.text.trim()) throw new Error('The AI returned an empty document.');
    const a = await saveArtifact({ title: `${state.title || 'Untitled Paper'} — ${t.title}`, kind, content: r.text.trim() + (r.truncated ? '\n\n*(This document reached its length limit.)*' : '') });
    openDocModal(a);
  } catch (err) { if (err.name !== 'AbortError') showToast(err.message, 6000); }
  finally { setBusy(''); }
}
async function renderArtifactsStack() {
  const all = (await dbGetAll('artifacts')).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  dom.artifactsCount.textContent = all.length;
  if (!all.length) { dom.artifactsList.innerHTML = '<div class="empty-state">Documents you create appear here, ready to open, download or insert into your paper.</div>'; return; }
  dom.artifactsList.innerHTML = all.map(a => `
    <div class="artifact-card doc-card">
      <div class="artifact-title">${escapeHTML(a.title)}</div>
      <p class="doc-meta">${a.createdAt ? fmtDate(a.createdAt) : ''} · ${words(a.content || '')} words${a.docId && a.docId !== state.currentDocId ? ' · from another paper' : ''}</p>
      <p class="doc-snippet">${escapeHTML(mdToPlain(a.content || '').slice(0, 160))}…</p>
      <div class="artifact-actions">
        <button class="btn-adopt" data-open-art="${a.id}">Open</button>
        <button class="btn-download" data-dl="${a.id}" data-f="pdf">PDF</button>
        <button class="btn-download" data-dl="${a.id}" data-f="docx">Word</button>
        <button class="btn-download" data-dl="${a.id}" data-f="md">MD</button>
        <button class="btn-download" data-dl="${a.id}" data-f="txt">TXT</button>
        <button class="btn-download danger" data-del-art="${a.id}" title="Delete">✕</button>
      </div>
    </div>`).join('');
  const find = (id) => all.find(x => x.id === id);
  dom.artifactsList.querySelectorAll('[data-open-art]').forEach(b => b.addEventListener('click', () => openDocModal(find(b.dataset.openArt))));
  dom.artifactsList.querySelectorAll('[data-dl]').forEach(b => b.addEventListener('click', () => { const a = find(b.dataset.dl); exportMarkdown(a.title, a.content, b.dataset.f); }));
  dom.artifactsList.querySelectorAll('[data-del-art]').forEach(b => b.addEventListener('click', async () => { if (confirm('Delete this document?')) { await dbDelete('artifacts', b.dataset.delArt); renderArtifactsStack(); } }));
}
function openDocModal(a) {
  if (!a) return;
  state.openDoc = a;
  $('doc-modal-title').textContent = a.title;
  $('doc-modal-meta').textContent = `${a.createdAt ? fmtDate(a.createdAt) : ''} · ${words(a.content)} words`;
  $('doc-modal-body').innerHTML = mdToHtml(a.content);
  show($('modal-doc'));
}

// ───────────────────────── The Stacks ─────────────────────────
async function renderStacks() {
  const items = await dbGetAll('stacks');
  dom.stacksCount.textContent = items.length;
  if (!items.length) { dom.stacksList.innerHTML = '<div class="empty-state">No reference documents yet.</div>'; return; }
  dom.stacksList.innerHTML = items.map(s => `
    <div class="stack-item">
      <div class="stack-info">
        <strong>${escapeHTML(s.name)}</strong>
        <span class="field-hint">${(s.size || 0) < 1024 ? (s.size || 0) + ' bytes' : (s.size || 0) < 1048576 ? ((s.size || 0) / 1024).toFixed(1) + ' KB' : ((s.size || 0) / 1048576).toFixed(1) + ' MB'} · ${words(s.text || '')} words extracted${s.blob ? '' : ' · original file not stored'}</span>
      </div>
      <div class="stack-actions">
        ${s.blob ? `<button class="btn-download" data-sdl="${s.id}" data-f="original">Original</button>` : ''}
        <button class="btn-download" data-sdl="${s.id}" data-f="pdf">PDF</button>
        <button class="btn-download" data-sdl="${s.id}" data-f="docx">Word</button>
        <button class="btn-download" data-sdl="${s.id}" data-f="md">MD</button>
        <button class="btn-download" data-sdl="${s.id}" data-f="txt">TXT</button>
        <button class="btn-download" data-sopen="${s.id}" title="Open this reference as a paper to read, appraise or revise">Open as paper</button>
        <button class="btn-download danger" data-sid="${s.id}" title="Remove">✕</button>
      </div>
    </div>`).join('');
  const find = (id) => items.find(x => x.id === id);
  dom.stacksList.querySelectorAll('[data-sdl]').forEach(b => b.addEventListener('click', () => {
    const s = find(b.dataset.sdl), title = s.name.replace(/\.[^/.]+$/, '');
    if (b.dataset.f === 'original') downloadBlob(s.blob, s.name);
    else exportMarkdown(title, s.text || '', b.dataset.f);
  }));
  dom.stacksList.querySelectorAll('[data-sopen]').forEach(b => b.addEventListener('click', async () => { const s = find(b.dataset.sopen); hide($('modal-stacks')); await newPaper(s.name.replace(/\.[^/.]+$/, ''), s.text || ''); showToast('Opened as a new paper.'); }));
  dom.stacksList.querySelectorAll('[data-sid]').forEach(b => b.addEventListener('click', async () => { await dbDelete('stacks', b.dataset.sid); renderStacks(); showToast('Removed from The Stacks.'); }));
}
async function handleStacksUpload(files) {
  const status = $('stacks-status');
  const say = (html, kind = '') => { if (status) { status.className = 'stacks-status ' + kind; status.innerHTML = html; } };
  let ok = 0; const failed = [];
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    say(`<span class="diode-dot"></span> Reading <strong>${escapeHTML(f.name)}</strong>${files.length > 1 ? ` (${i + 1} of ${files.length})` : ''}…`);
    try {
      const { text } = await extractText(f);
      if (!text.trim()) throw new Error('no readable text was found');
      const item = { id: 'stack_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6), name: f.name, size: f.size, type: f.type, text, uploadedAt: new Date().toISOString() };
      // keep the original file too; if this browser can't store it, keep the text and say so
      const saved = await dbSave('stacks', { ...item, blob: f });
      if (!saved && db) await dbSave('stacks', item);
      ok++;
    } catch (err) { failed.push(`${f.name}: ${err.message}`); }
    await renderStacks();
  }
  const where = db ? '' : ' They’re kept for now and will be stored on this computer once the older Artificience window is closed.';
  if (ok && !failed.length) say(`✓ Added ${ok} reference${ok === 1 ? '' : 's'}. The evaluator now reads ${ok === 1 ? 'it' : 'them'} as context.${where}`, 'ok');
  else if (ok) say(`✓ Added ${ok}. Couldn’t read: ${failed.map(escapeHTML).join('; ')}`, 'warn');
  else say(`Couldn’t add ${failed.length === 1 ? 'this file' : 'these files'}: ${failed.map(escapeHTML).join('; ')}`, 'warn');
  if (ok) showToast(`Added ${ok} document${ok === 1 ? '' : 's'} to The Stacks.`);
}

// ───────────────────────── Versions ─────────────────────────
async function restoreMenuLegacy() {
  const versions = (await dbGetAll('versions')).filter(v => v.docId === state.currentDocId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (!versions.length) { showToast('No earlier versions of this paper yet. One is saved each time you apply revisions.'); return; }
  const list = versions.slice(0, 8).map((v, i) => `${i + 1}. ${fmtDate(v.createdAt)} ${new Date(v.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} — ${words(v.content)} words`).join('\n');
  const pick = prompt(`Restore an earlier version of this paper?\n\n${list}\n\nType a number (your current text is saved as a version first):`);
  const v = versions[(+pick || 0) - 1];
  if (!v) return;
  await dbSave('versions', { id: 'ver_' + Date.now() + 'b', docId: state.currentDocId, title: state.title, content: state.content, html: RichEditor.getHtml(), docStyle: RichEditor.getDocStyle(), createdAt: new Date().toISOString(), note: 'Before restoring' });
  RichEditor.setHtml(v.html || RichEditor.fromMarkdown(v.content), v.docStyle); handleEditorInput(); showToast('Earlier version restored.');
}

// ───────────────────────── Tabs ─────────────────────────
function selectTab(name) {
  document.querySelectorAll('.panel-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('#evaluator-panel > .panel-scroll-well').forEach(v => v.classList.toggle('hidden', v.id !== 'view-' + name));
  if (name === 'artifacts') renderArtifactsStack();
  window.Features?.onTab?.(name);
}

// ───────────────────────── Boot ─────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  loadStoredState();
  RichEditor.init({ page: dom.editor, host: dom.dropzone, toolbarHost: $('rt-toolbar-host'), onChange: handleEditorInput, onSelection: captureSelection });
  bindUI();          // every button works immediately, even while saved papers are loading
  updateEngineStatus();
  await initDB();
  await loadDurableSettings();
  await loadDocument();
  await renderStacks();
  updateEngineStatus();
});

function bindUI() {

  dom.profileLevelLabel.textContent = profileLabel();
  $('prof-tier-select').value = state.profile.tier;
  $('prof-major-input').value = state.profile.major;
  $('prof-gpa-input').value = state.profile.gpa;
  $('cfg-api-url').value = state.settings.apiUrl;
  $('cfg-api-key').value = state.settings.apiKey;
  $('cfg-model').value = state.settings.model;
  $('cfg-custom-standards').value = state.settings.customStandards;
  $('cfg-intensity').value = state.settings.intensity || 'standard';
  $('cfg-export-style').value = state.settings.exportStyle || 'academic';

  $('btn-toggle-panel').addEventListener('click', () => dom.evaluatorPanel.classList.toggle('collapsed'));
  dom.docTitleInput.addEventListener('blur', () => { dom.docTitleInput.scrollLeft = 0; });
  dom.docTitleInput.addEventListener('input', (e) => { state.title = e.target.value; clearTimeout(saveTimer); saveTimer = setTimeout(persistDocument, 700); });
  dom.editor.addEventListener('keyup', captureSelection);
  dom.editor.addEventListener('mouseup', captureSelection);
  dom.frameworkSelect.addEventListener('change', (e) => { state.activeFramework = e.target.value; persistDocument(); });

  dom.btnAppraise.addEventListener('click', () => runAppraisal());
  dom.btnRevise.addEventListener('click', () => runRevisions());

  $('btn-accept-all-diff').addEventListener('click', () => { state.review?.edits.forEach((e, i) => { if (e.status === 'pending') decide(i, 'accepted', true); }); showToast('All changes kept. Choose “Apply my decisions”.'); });
  $('btn-reject-all-diff').addEventListener('click', () => { state.review?.edits.forEach((e, i) => { if (e.status === 'pending') decide(i, 'rejected', true); }); showToast('All changes rejected.'); });
  $('btn-finish-diff-review').addEventListener('click', applyDecisions);
  $('btn-cancel-review').addEventListener('click', cancelReview);

  $('mode-ask').addEventListener('click', () => setMode('ask'));
  $('mode-revise').addEventListener('click', () => setMode('revise'));
  $('btn-send-directive').addEventListener('click', sendDirective);
  dom.directive.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendDirective(); } });
  // grow the box with what you type, up to a limit
  dom.directive.addEventListener('input', () => { dom.directive.style.height = 'auto'; dom.directive.style.height = Math.min(140, dom.directive.scrollHeight) + 'px'; });

  dom.fileImport.addEventListener('change', (e) => { if (e.target.files?.[0]) processUploadedFile(e.target.files[0]); e.target.value = ''; });
  ['dragenter', 'dragover'].forEach(ev => dom.dropzone.addEventListener(ev, (e) => { e.preventDefault(); dom.dropzone.classList.add('dragging'); }));
  ['dragleave', 'drop'].forEach(ev => dom.dropzone.addEventListener(ev, (e) => { e.preventDefault(); dom.dropzone.classList.remove('dragging'); }));
  dom.dropzone.addEventListener('drop', async (e) => { const files = [...(e.dataTransfer?.files || [])]; for (const f of files) await processUploadedFile(f); });

  $('btn-profile-toggle').addEventListener('click', () => show($('modal-profile')));
  $('btn-close-profile').addEventListener('click', () => hide($('modal-profile')));
  $('btn-save-profile').addEventListener('click', () => {
    const sel = $('prof-tier-select');
    state.profile.tier = sel.value; state.profile.tierLabel = sel.value ? sel.options[sel.selectedIndex].text : '';
    state.profile.major = $('prof-major-input').value.trim();
    state.profile.gpa = $('prof-gpa-input').value.trim();
    dom.profileLevelLabel.textContent = profileLabel();
    saveProfileState(); hide($('modal-profile'));
  });

  $('btn-open-stacks').addEventListener('click', () => show($('modal-stacks')));
  $('btn-close-stacks').addEventListener('click', () => hide($('modal-stacks')));
  $('stacks-dropzone-box').addEventListener('click', () => dom.stacksInput.click());
  ['dragenter', 'dragover'].forEach(ev => $('stacks-dropzone-box').addEventListener(ev, (e) => e.preventDefault()));
  const stacksDialog = document.querySelector('#modal-stacks .modal-dialog');
  ['dragenter', 'dragover'].forEach(ev => stacksDialog.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); $('stacks-dropzone-box').classList.add('dragging'); }));
  stacksDialog.addEventListener('dragleave', (e) => { if (!stacksDialog.contains(e.relatedTarget)) $('stacks-dropzone-box').classList.remove('dragging'); });
  stacksDialog.addEventListener('drop', (e) => { e.preventDefault(); e.stopPropagation(); $('stacks-dropzone-box').classList.remove('dragging'); const files = [...(e.dataTransfer?.files || [])]; if (files.length) handleStacksUpload(files); });
  // never let a stray drop navigate the window away to the file
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => e.preventDefault());
  dom.stacksInput.addEventListener('change', (e) => { const files = [...(e.target.files || [])]; e.target.value = ''; if (files.length) handleStacksUpload(files); });

  $('btn-export-popover').addEventListener('click', (e) => { e.stopPropagation(); RichEditor.closeMenus(); dom.exportMenu.classList.toggle('hidden'); });
  $('btn-backup-workspace').addEventListener('click', exportFullWorkspaceJson);
  dom.exportMenu.querySelectorAll('[data-export]').forEach(b => b.addEventListener('click', () => { hide(dom.exportMenu); exportPaper(b.dataset.export); }));
  document.addEventListener('click', (e) => { if (!e.target.closest('#export-popover-menu')) hide(dom.exportMenu); });

  $('btn-open-settings').addEventListener('click', () => show($('modal-settings')));
  $('btn-close-settings').addEventListener('click', () => hide($('modal-settings')));
  const readSettings = () => {
    state.settings.apiUrl = $('cfg-api-url').value.trim() || 'https://api.openai.com/v1';
    state.settings.apiKey = $('cfg-api-key').value.trim();
    state.settings.model = $('cfg-model').value.trim() || 'gpt-4o-mini';
    state.settings.customStandards = $('cfg-custom-standards').value.trim();
    state.settings.intensity = $('cfg-intensity').value;
    state.settings.exportStyle = $('cfg-export-style').value;
  };
  $('btn-save-settings').addEventListener('click', () => { readSettings(); saveSettingsState(); updateEngineStatus(); hide($('modal-settings')); });
  $('btn-test-connection').addEventListener('click', async () => {
    readSettings();
    const out = $('connection-result'); out.textContent = 'Testing…';
    try { const r = await callChat({ system: 'Reply with the single word: ready', user: 'Connection test', maxTokens: 5 }); out.textContent = `Connected to ${state.settings.model}. Reply: “${r.text.trim()}”. Remember to Save Settings.`; }
    catch (err) { out.textContent = err.message; }
  });
  $('btn-reset-workspace').addEventListener('click', () => { if (confirm('Erase all Artificience papers, documents, references and settings on this computer?')) { indexedDB.deleteDatabase(DB_NAME); localStorage.clear(); location.reload(); } });

  $('btn-close-doc').addEventListener('click', () => hide($('modal-doc')));
  document.querySelectorAll('[data-docdl]').forEach(b => b.addEventListener('click', () => { const a = state.openDoc; if (a) exportMarkdown(a.title, a.content, b.dataset.docdl); }));
  $('btn-doc-insert').addEventListener('click', () => {
    const a = state.openDoc; if (!a) return;
    if (state.review) { showToast('Apply or cancel the open revision review first.'); return; }
    appendPaperMarkdown(`## ${a.title.replace(/^.* — /, '')}\n\n` + a.content); hide($('modal-doc')); showToast('Inserted at the end of your paper.');
  });
  $('btn-doc-open').addEventListener('click', async () => { const a = state.openDoc; if (!a) return; if (state.review) { showToast('Apply or cancel the open revision review first.'); return; } hide($('modal-doc')); await newPaper(a.title, a.content); showToast('Opened as a new paper.'); });
  $('btn-close-prompt').addEventListener('click', () => hide($('modal-prompt')));
  $('prompt-input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) $('btn-prompt-go').click(); });

  document.querySelectorAll('[data-make]').forEach(b => b.addEventListener('click', () => makeDocument(b.dataset.make)));
  document.querySelectorAll('.panel-tab').forEach(t => t.addEventListener('click', () => selectTab(t.dataset.tab)));

  window.addEventListener('keydown', (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); if (e.shiftKey) runRevisions({ range: state.selection ? selectionRange() : null }); else runAppraisal(); return; }
    if ((e.metaKey || e.ctrlKey) && e.key === 's') { e.preventDefault(); persistDocument(); showToast('Paper saved on this computer.'); return; }
    if ((e.metaKey || e.ctrlKey) && e.key === 'e') { e.preventDefault(); dom.evaluatorPanel.classList.toggle('collapsed'); return; }
    if (e.key === 'Escape') { document.querySelectorAll('.modal-backdrop').forEach(hide); hide(dom.exportMenu); RichEditor.closeMenus(); return; }
    if (state.review && !typing && !e.metaKey && !e.ctrlKey) {
      const edits = state.review.edits, i = state.reviewCursor;
      const k = e.key.toLowerCase();
      if (k === 'j' || e.key === 'ArrowDown') { e.preventDefault(); focusEdit(Math.min(edits.length - 1, i + 1)); }
      else if (k === 'k' || e.key === 'ArrowUp') { e.preventDefault(); focusEdit(Math.max(0, i - 1)); }
      else if (k === 'y' && i >= 0) { e.preventDefault(); decide(i, 'accepted'); }
      else if (k === 'n' && i >= 0) { e.preventDefault(); decide(i, 'rejected'); }
      else if (k === 'u') { e.preventDefault(); undoDecision(); }
    }
  });

  // Header: every control opens something useful
  $('btn-brand').addEventListener('click', (e) => { e.stopPropagation(); RichEditor.openMenu($('btn-brand'), [
    { key: 'papers', label: 'Your papers…', run: openPapers },
    { key: 'profile', label: 'Scholar profile…', run: () => show($('modal-profile')) },
    { key: 'new', label: 'New paper', run: () => App.newPaper() },
    { key: 'import', label: 'Import a file…', run: () => dom.fileImport.click() },
    '-',
    { key: 'how', label: 'How Artificience works', run: () => showHelp('how') },
    { key: 'keys', label: 'Keyboard shortcuts', run: () => showHelp('keys') },
    { key: 'settings', label: 'Settings & AI engine', run: () => show($('modal-settings')) },
    { key: 'about', label: 'About Artificience', run: () => showHelp('about') }]); });
  $('save-pill').addEventListener('click', async () => { await persistDocument(); showToast('Saved on this computer.'); });
  $('btn-engine-status').addEventListener('click', (e) => { e.stopPropagation(); engineStatusPopover(); });
  $('btn-close-info').addEventListener('click', closeInfo);
  document.querySelectorAll('.modal-backdrop').forEach(m => m.addEventListener('mousedown', (e) => { if (e.target === m) hide(m); }));
}

function updateEngineStatus() {
  const ok = !!(state.settings.apiKey || !/openai\.com/.test(state.settings.apiUrl));
  $('engine-dot').classList.toggle('off', !ok);
  $('engine-label').textContent = ok ? state.settings.model : 'Connect AI';
}
function engineStatusPopover() {
  const ok = !!(state.settings.apiKey || !/openai\.com/.test(state.settings.apiUrl));
  const pop = RichEditor.popover($('btn-engine-status'), `<div class="engine-pop">
    <div class="engine-row"><span>Status</span><strong>${ok ? 'Ready' : 'No API key yet'}</strong></div>
    <div class="engine-row"><span>Model</span><strong>${escapeHTML(state.settings.model)}</strong></div>
    <div class="engine-row"><span>Endpoint</span><strong>${escapeHTML(state.settings.apiUrl.replace(/^https?:\/\//, ''))}</strong></div>
    <div class="engine-row"><span>Revision depth</span><strong>${escapeHTML(state.settings.intensity || 'standard')}</strong></div>
    <div class="engine-row"><span>Lens</span><strong>${escapeHTML(LENS_NAMES()[state.activeFramework] || '')}</strong></div>
    <div class="engine-actions"><button class="btn-mini" id="eng-test">Test connection</button><button class="btn-mini ghost" id="eng-settings">Settings…</button></div>
    <p class="field-hint" id="eng-out"></p></div>`, 'rt-palette engine-popover');
  const r = $('btn-engine-status').getBoundingClientRect(); pop.style.left = Math.max(8, r.right - pop.offsetWidth) + 'px';
  pop.querySelector('#eng-settings').addEventListener('click', () => { RichEditor.closeMenus(); show($('modal-settings')); });
  pop.querySelector('#eng-test').addEventListener('click', async () => { const out = pop.querySelector('#eng-out'); out.textContent = 'Testing…'; try { await callChat({ system: 'Reply with the single word: ready', user: 'Connection test', maxTokens: 5 }); out.textContent = 'Connected.'; } catch (err) { out.textContent = err.message; } });
}

// Commands used by the menus and toolbar
const App = {
  newPaper: async () => { if (state.review) { showToast('Apply or cancel the open revision review first.'); return; } await newPaper(); showToast('New paper ready. Find your others under File → Open.'); },
  openPapers, duplicatePaper, deleteCurrentPaper, exportPaper, restoreMenu: () => window.Features?.versions(),
  runAppraisal: () => runAppraisal(), runRevisions: () => runRevisions({ range: state.selection ? selectionRange() : null }), reviseSelection,
  selectTab: (t) => { dom.evaluatorPanel.classList.remove('collapsed'); selectTab(t); },
  showHelp, info: showInfo, closeInfo, toast: showToast
};
window.App = App;

// Internals shared with features.js
window.__ai = { persistSettings, persistProfile, state, dbSave, dbGetAll, dbGet, dbDelete, persistDocument, applyRecord, newPaper, handleEditorInput, showToast, showInfo, closeInfo, selectTab, runRevisions, runAppraisal, escapeHTML, fmtDate, words, exportMarkdown, downloadBlob, safeName, printHtml, memoMarkdown, LENS_NAMES, RUBRIC_LENSES, FOCUS_AREAS, saveSettingsState, saveProfileState, contextBlock, callChat, renderAppraisalFeed, show, hide, saveArtifact, openDocModal };
// Exposed for automated checks
window.__artificience = { locate, mdToBlocks, mdToHtml, mdToPlain, toEdit, splitSections, htmlToText, state };
