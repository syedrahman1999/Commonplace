/* Artificience 4.3 mobile shell: the exact same editor and evaluator, single-pane presentation. */
(() => {
  const isMobile = () => window.matchMedia('(max-width: 900px)').matches;
  const root = document.getElementById('workspace');
  const nav = document.getElementById('mobile-workspace-nav');
  if (!root || !nav) return;
  let view = 'paper';
  const dot = document.getElementById('mobile-notice-dot');
  const setView = (next, focus = false) => {
    if (next !== 'paper' && next !== 'evaluator') return;
    view = next;
    root.dataset.mobileView = next;
    nav.querySelectorAll('[data-mobile-view]').forEach(btn => {
      const active = btn.dataset.mobileView === next;
      btn.classList.toggle('active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
    if (next === 'evaluator') {
      if (dot) dot.classList.remove('visible');
    }
    if (focus && isMobile()) {
      if (next === 'paper') document.getElementById('manuscript-editor')?.focus({ preventScroll: true });
    }
  };
  root.dataset.mobileView = 'paper';
  nav.querySelectorAll('[data-mobile-view]').forEach(b => b.addEventListener('click', () => setView(b.dataset.mobileView)));
  document.getElementById('btn-mobile-import')?.addEventListener('click', () => document.getElementById('omnibox-file-import')?.click());
  document.getElementById('btn-mobile-profile')?.addEventListener('click', () => document.getElementById('btn-profile-toggle')?.click());
  document.getElementById('btn-appraise')?.addEventListener('click', () => {
    if (isMobile() && document.getElementById('manuscript-editor')?.textContent?.trim()) setView('evaluator');
  });
  // View changes are deliberately explicit: tracked revisions stay visible in the paper.
  document.querySelectorAll('.panel-tab').forEach(b => b.addEventListener('click', () => {
    if (isMobile()) setView('evaluator');
  }));
  const origAppSelect = window.App?.selectTab;
  if (window.App && typeof origAppSelect === 'function') {
    window.App.selectTab = (name) => { origAppSelect(name); if (isMobile()) setView('evaluator'); };
  }
  const toggle = document.getElementById('btn-toggle-panel');
  if (toggle) toggle.addEventListener('click', () => { if (isMobile()) setView(view === 'paper' ? 'evaluator' : 'paper'); });
  const menu = document.getElementById('export-popover-menu');
  const menuHolder = document.querySelector('.popover-wrapper');
  const alignExportMenu = () => {
    // Horizontal scrolling in the mobile header must not clip the export sheet.
    if (!menu || !menuHolder) return;
    if (isMobile() && menu.parentElement !== document.body) document.body.appendChild(menu);
    else if (!isMobile() && menu.parentElement !== menuHolder) menuHolder.appendChild(menu);
  };
  const focusObserver = new MutationObserver(() => {
    if (isMobile() && document.body.classList.contains('focus-mode')) setView('paper');
  });
  focusObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
  const updateViewport = () => {
    alignExportMenu();
    // On iOS the visual viewport shrinks when the keyboard opens.
    // Using its height lets the evaluator's Ask input stay above the keyboard.
    if (isMobile() && window.visualViewport) {
      document.documentElement.style.setProperty('--artificience-viewport-height', `${Math.round(window.visualViewport.height)}px`);
    } else {
      document.documentElement.style.removeProperty('--artificience-viewport-height');
    }
  };
  window.visualViewport?.addEventListener('resize', updateViewport);
  window.addEventListener('resize', updateViewport);
  window.addEventListener('orientationchange', updateViewport);
  updateViewport();
  window.ArtificienceMobile = { isMobile, open: setView, getView: () => view };
})();
